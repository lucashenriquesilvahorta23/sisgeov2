<?php

namespace App\Controllers;
use App\Models\AlunoModel;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Libraries\Auth;
use \DateTime;

class Aluno extends BaseController
{
    public function initController(
        RequestInterface $request,
        ResponseInterface $response,
        LoggerInterface $logger
    ) {
        parent::initController($request, $response, $logger);
        $this->session = \Config\Services::session();
        $this->usuario = $this->session->get('dadoslogin');
        if($this->usuario == null){
            header('Location: '.base_url());
            exit(); 
        }
		date_default_timezone_set('America/Sao_Paulo');
        $this->alunoModel = new AlunoModel();
        $this->auth = new Auth();
        helper('complementos');
    }


    public function index(){
        $dados = array();
        $dados['resultados'] = $this->alunoModel->getAluno();
        echo view('commons/header');	          
        echo view('commons/navbartop');
        echo view('commons/navbarleft', getBarMenu($this->usuario));	
        echo view('alunos/aluno', $dados);
        echo view('commons/footer');
    }

    public function Inserir(){
        echo view('commons/header');
        echo view('commons/navbartop');
        echo view('commons/navbarleft', getBarMenu($this->usuario));
        echo view('alunos/aluno_cadastro');
        echo view('commons/footer');
    }

    public function Store(){
        $dados = array();
        $id = $this->request->getPost('aluno_id');
        if($id == ""){
            $dados['NIS_ALUNO'] = $this->request->getPost('aluno_nis'); 
            $dados['NOME_ALUNO'] = $this->request->getPost('aluno_nome'); 
            $dados['DATA_NASCIMENTO'] = $this->request->getPost('aluno_data_nascimento'); 
            $dados['IDADE'] = $this->request->getPost('aluno_idade'); 
            $dados['SEXO'] = $this->request->getPost('aluno_sexo'); 
            $dados['NATURALIDADE'] = $this->request->getPost('aluno_naturalidade'); 
            $dados['ESTADO_NATURALIDADE'] = $this->request->getPost('aluno_estado_naturalidade'); 
            $dados['NACIONALIDADE'] = $this->request->getPost('aluno_nacionalidade'); 
            $dados['CPF'] = $this->request->getPost('aluno_cpf'); 
            $dados['DATA_EMISSAO'] = $this->request->getPost('aluno_data_emissao'); 
            $dados['ORGAO_EXPEDITOR'] = $this->request->getPost('aluno_orgao_expeditor'); 
            $dados['NUMERO_MATRICULA'] = $this->request->getPost('aluno_numero_matricula'); 
            $dados['COR_RACA'] = $this->request->getPost('aluno_cor_raca'); 
            $dados['FILIACAO_1'] = $this->request->getPost('aluno_filiacao_1'); 
            $dados['FILIACAO_1_VIVO'] = $this->request->getPost('aluno_filiacao_1_vivo'); 
            $dados['FILIACAO_1_TELEFONE'] = $this->request->getPost('aluno_filiacao_1_telefone'); 
            $dados['FILIACAO_1_PROFISSAO'] = $this->request->getPost('aluno_filiacao_1_profissao'); 
            $dados['FILIACAO_2'] = $this->request->getPost('aluno_filiacao_2'); 
            $dados['FILIACAO_2_VIVO'] = $this->request->getPost('aluno_filiacao_2_vivo'); 
            $dados['FILIACAO_2_TELEFONE'] = $this->request->getPost('aluno_filiacao_2_telefone'); 
            $dados['FILIACAO_2_PROFISSAO'] = $this->request->getPost('aluno_filiacao_2_profissao'); 
            $dados['RESPONSAVEL_LEGAL'] = $this->request->getPost('aluno_responsavel_legal'); 
            $dados['RESPONSAVEL_LEGAL_NOME'] = $this->request->getPost('aluno_responsavel_legal_nome'); 
            $dados['GRAU_PARENTESCO'] = $this->request->getPost('aluno_grau_parentesco'); 
            $dados['RESPONSAVEL_LEGAL_TELEFONE'] = $this->request->getPost('aluno_responsavel_legal_telefone'); 
            $dados['RESPONSAVEL_LEGAL_PROFISSAO'] = $this->request->getPost('aluno_responsavel_legal_profissao'); 
            $dados['ENDERECO'] = $this->request->getPost('aluno_endereco'); 
            $dados['NUMERO'] = $this->request->getPost('aluno_numero'); 
            $dados['BAIRRO'] = $this->request->getPost('aluno_bairro'); 
            $dados['CIDADE'] = $this->request->getPost('aluno_cidade'); 
            $dados['ESTADO'] = $this->request->getPost('aluno_estado'); 
            $dados['POSSUI_DEFICIENCIA'] = $this->request->getPost('aluno_possui_deficiencia'); 
            $dados['POSSUI_TRANSTORNO'] = $this->request->getPost('aluno_possui_transtorno'); 
            $dados['POSSUI_DOENCAS_CRONICAS'] = $this->request->getPost('aluno_possui_doencas_cronicas'); 
            $dados['POSSUI_SUPERDOTACAO'] = $this->request->getPost('aluno_possui_superdotacao'); 

            $arquivo = $this->request->getFile('aluno_imagem');

            if($arquivo != "" && $arquivo != null){
                $input = $this->validate([
                    'file' => [
                        'uploaded[aluno_imagem]',
                        'mime_in[aluno_imagem,image/jpg,image/jpeg,image/png]',
                        'max_size[aluno_imagem,2048]',
                    ]
                ]);
                    
                if (!$input) {
                    return redirect()->to('/Aluno/index?tipo_msg=erro&msg=Arquivo inválido!');
                } else {
                    $img = $this->request->getFile('aluno_imagem');
    
                    $nome_aleatorio = $img->getRandomName();
                    $img->move($_SERVER['DOCUMENT_ROOT'].'/uploads',$nome_aleatorio);
    
                    $dados['NOME_ALEATORIO'] = $nome_aleatorio;        
                }
            }

            $insert_id = $this->alunoModel->setAluno($dados);

            if($this->request->getPost('aluno_possui_deficiencia') == "S"){
                $deficiencia = array();
                $deficiencia['FK_ID_ALUNO'] = $insert_id;
                $deficiencia['BAIXA_VISAO'] = $this->request->getPost('aluno_baixa_visao');
                $deficiencia['DEFICIENCIA_FISICA'] = $this->request->getPost('aluno_deficiencia_fisica');
                $deficiencia['SURDOCEGUEIRA'] = $this->request->getPost('aluno_surdocegueira');
                $deficiencia['CEGUEIRA'] = $this->request->getPost('aluno_cegueira');
                $deficiencia['INTELECTUAL'] = $this->request->getPost('aluno_intelectual');
                $deficiencia['MULTIPLA'] = $this->request->getPost('aluno_multipla');
                $deficiencia['AUDITIVA'] = $this->request->getPost('aluno_auditiva');
                $deficiencia['SURDEZ'] = $this->request->getPost('aluno_surdez');
                $deficiencia['OUTROS'] = $this->request->getPost('aluno_outros');
                $this->alunoModel->setDeficiencia($deficiencia);
            }

            if($this->request->getPost('aluno_possui_transtorno') == "S"){
                $transtorno = array();
                $transtorno['FK_ID_ALUNO'] = $insert_id;
                $transtorno['AUSTISMO'] = $this->request->getPost('aluno_autismo');
                $transtorno['TDAH'] = $this->request->getPost('aluno_tdah');
                $transtorno['OUTROS'] = $this->request->getPost('aluno_outros_transtornos');
                $this->alunoModel->setTranstorno($transtorno);
            }

            if($this->request->getPost('aluno_possui_doencas_cronicas') == "S"){
                $doencas_cronicas = array();
                $doencas_cronicas['FK_ID_ALUNO'] = $insert_id;
                $doencas_cronicas['DIEABETE'] = $this->request->getPost('aluno_diabete');
                $doencas_cronicas['RESPIRATORIA'] = $this->request->getPost('aluno_respiratoria');
                $doencas_cronicas['NEUROLOGIA'] = $this->request->getPost('aluno_neurologia');
                $doencas_cronicas['OBESIDADE'] = $this->request->getPost('aluno_obesidade');
                $doencas_cronicas['OUTROS'] = $this->request->getPost('aluno_outros_cronicas');
                $this->alunoModel->setDoencaCronica($doencas_cronicas);
            }

            if($insert_id){
                return redirect()->to('/Aluno/index?tipo_msg=sucesso&msg=Ação realizada!');
            }else{
                return redirect()->to('/Aluno/index?tipo_msg=erro&msg=Erro ao realizar ação!');
            }
        }else{
            $dados['ID_ALUNO'] = $this->request->getPost('aluno_id'); 
            $dados['NIS_ALUNO'] = $this->request->getPost('aluno_nis'); 
            $dados['NOME_ALUNO'] = $this->request->getPost('aluno_nome'); 
            $dados['DATA_NASCIMENTO'] = $this->request->getPost('aluno_data_nascimento'); 
            $dados['IDADE'] = $this->request->getPost('aluno_idade'); 
            $dados['SEXO'] = $this->request->getPost('aluno_sexo'); 
            $dados['NATURALIDADE'] = $this->request->getPost('aluno_naturalidade'); 
            $dados['ESTADO_NATURALIDADE'] = $this->request->getPost('aluno_estado_naturalidade'); 
            $dados['NACIONALIDADE'] = $this->request->getPost('aluno_nacionalidade'); 
            $dados['CPF'] = $this->request->getPost('aluno_cpf'); 
            $dados['DATA_EMISSAO'] = $this->request->getPost('aluno_data_emissao'); 
            $dados['ORGAO_EXPEDITOR'] = $this->request->getPost('aluno_orgao_expeditor'); 
            $dados['NUMERO_MATRICULA'] = $this->request->getPost('aluno_numero_matricula'); 
            $dados['COR_RACA'] = $this->request->getPost('aluno_cor_raca'); 
            $dados['CAD_ALUNOcol'] = $this->request->getPost('aluno_cad_alunocol'); 
            $dados['FILIACAO_1'] = $this->request->getPost('aluno_filiacao_1'); 
            $dados['FILIACAO_1_VIVO'] = $this->request->getPost('aluno_filiacao_1_vivo'); 
            $dados['FILIACAO_1_TELEFONE'] = $this->request->getPost('aluno_filiacao_1_telefone'); 
            $dados['FILIACAO_1_PROFISSAO'] = $this->request->getPost('aluno_filiacao_1_profissao'); 
            $dados['FILIACAO_2'] = $this->request->getPost('aluno_filiacao_2'); 
            $dados['FILIACAO_2_VIVO'] = $this->request->getPost('aluno_filiacao_2_vivo'); 
            $dados['FILIACAO_2_TELEFONE'] = $this->request->getPost('aluno_filiacao_2_telefone'); 
            $dados['FILIACAO_2_PROFISSAO'] = $this->request->getPost('aluno_filiacao_2_profissao'); 
            $dados['RESPONSAVEL_LEGAL'] = $this->request->getPost('aluno_responsavel_legal'); 
            $dados['RESPONSAVEL_LEGAL_NOME'] = $this->request->getPost('aluno_responsavel_legal_nome'); 
            $dados['GRAU_PARENTESCO'] = $this->request->getPost('aluno_grau_parentesco'); 
            $dados['RESPONSAVEL_LEGAL_TELEFONE'] = $this->request->getPost('aluno_responsavel_legal_telefone'); 
            $dados['RESPONSAVEL_LEGAL_PROFISSAO'] = $this->request->getPost('aluno_responsavel_legal_profissao'); 
            $dados['ENDERECO'] = $this->request->getPost('aluno_endereco'); 
            $dados['NUMERO'] = $this->request->getPost('aluno_numero'); 
            $dados['BAIRRO'] = $this->request->getPost('aluno_bairro'); 
            $dados['CIDADE'] = $this->request->getPost('aluno_cidade'); 
            $dados['ESTADO'] = $this->request->getPost('aluno_estado'); 
            $dados['POSSUI_DEFICIENCIA'] = $this->request->getPost('aluno_possui_deficiencia'); 
            $dados['POSSUI_TRANSTORNO'] = $this->request->getPost('aluno_possui_transtorno'); 
            $dados['POSSUI_DOENCAS_CRONICAS'] = $this->request->getPost('aluno_possui_doencas_cronicas'); 
            $dados['POSSUI_SUPERDOTACAO'] = $this->request->getPost('aluno_possui_superdotacao'); 

            $arquivo = $this->request->getFile('aluno_imagem');

            if($arquivo != "" && $arquivo != null){
                $input = $this->validate([
                    'file' => [
                        'uploaded[aluno_imagem]',
                        'mime_in[aluno_imagem,image/jpg,image/jpeg,image/png]',
                        'max_size[aluno_imagem,2048]',
                    ]
                ]);
                    
                if (!$input) {
                    return redirect()->to('/Aluno/index?tipo_msg=erro&msg=Arquivo inválido!');
                } else {
                    $img = $this->request->getFile('aluno_imagem');
    
                    $nome_aleatorio = $img->getRandomName();
                    $img->move($_SERVER['DOCUMENT_ROOT'].'/uploads',$nome_aleatorio);
    
                    $dados['NOME_ALEATORIO'] = $nome_aleatorio;        
                }
            }

            $this->alunoModel->updateAluno($dados);

            $this->alunoModel->deleteDeficiencia($id);
            if($this->request->getPost('aluno_possui_deficiencia') == "S"){
                $deficiencia = array();
                $deficiencia['ID_ALUNO_DEFICIENCIA'] = $this->request->getPost('aluno_id_deficiencia');
                $deficiencia['FK_ID_ALUNO'] = $id;
                $deficiencia['BAIXA_VISAO'] = $this->request->getPost('aluno_baixa_visao');
                $deficiencia['DEFICIENCIA_FISICA'] = $this->request->getPost('aluno_deficiencia_fisica');
                $deficiencia['SURDOCEGUEIRA'] = $this->request->getPost('aluno_surdocegueira');
                $deficiencia['CEGUEIRA'] = $this->request->getPost('aluno_cegueira');
                $deficiencia['INTELECTUAL'] = $this->request->getPost('aluno_intelectual');
                $deficiencia['MULTIPLA'] = $this->request->getPost('aluno_multipla');
                $deficiencia['AUDITIVA'] = $this->request->getPost('aluno_auditiva');
                $deficiencia['SURDEZ'] = $this->request->getPost('aluno_surdez');
                $deficiencia['OUTROS'] = $this->request->getPost('aluno_outros');
                $this->alunoModel->setDeficiencia($deficiencia);
            }

            $this->alunoModel->deleteTranstorno($id);
            if($this->request->getPost('aluno_possui_transtorno') == "S"){
                $transtorno = array();
                $transtorno['ID_ALUNO_TRANSTORNO'] = $this->request->getPost('aluno_id_transtorno');
                $transtorno['FK_ID_ALUNO'] = $id;
                $transtorno['AUSTISMO'] = $this->request->getPost('aluno_autismo');
                $transtorno['TDAH'] = $this->request->getPost('aluno_tdah');
                $transtorno['OUTROS'] = $this->request->getPost('aluno_outros_transtornos');
                $this->alunoModel->setTranstorno($transtorno);
            }

            $this->alunoModel->deleteDoencaCronica($id);
            if($this->request->getPost('aluno_possui_doencas_cronicas') == "S"){
                $doencas_cronicas = array();
                $doencas_cronicas['ID_ALUNO_CRONICA'] = $this->request->getPost('aluno_id_cronica');
                $doencas_cronicas['FK_ID_ALUNO'] = $id;
                $doencas_cronicas['DIEABETE'] = $this->request->getPost('aluno_diabete');
                $doencas_cronicas['RESPIRATORIA'] = $this->request->getPost('aluno_respiratoria');
                $doencas_cronicas['NEUROLOGIA'] = $this->request->getPost('aluno_neurologia');
                $doencas_cronicas['OBESIDADE'] = $this->request->getPost('aluno_obesidade');
                $doencas_cronicas['OUTROS'] = $this->request->getPost('aluno_outros_cronicas');
                $this->alunoModel->setDoencaCronica($doencas_cronicas);
            }

            if($id){
                return redirect()->to('/Aluno/index?tipo_msg=sucesso&msg=Ação realizada!');
            }else{
                return redirect()->to('/Aluno/index?tipo_msg=erro&msg=Erro ao realizar ação!');
            }

        }
    }

    public function Editar($id=""){
        $dados['aluno'] = $this->alunoModel->getAlunoID(base64_decode($id));
        $dados['aluno_deficiencia'] = $this->alunoModel->getDeficiencia(base64_decode($id));
        $dados['aluno_transtorno'] = $this->alunoModel->getTranstorno(base64_decode($id));
        $dados['aluno_doencas_cronicas'] = $this->alunoModel->getDoenca(base64_decode($id));
        echo view('commons/header');
        echo view('commons/navbartop');
        echo view('commons/navbarleft', getBarMenu($this->usuario));
        echo view('alunos/aluno_cadastro', $dados);
        echo view('commons/footer');
    }

    public function Excluir($id=""){
        if($this->alunoModel->deleteAluno(base64_decode($id))){
            return redirect()->to('/Aluno/index?tipo_msg=sucesso&msg=Ação realizada!');
        }else{
            return redirect()->to('/Aluno/index?tipo_msg=erro&msg=Erro ao realizar ação!');
        }
    }
}
