<?php

namespace App\Controllers;
use App\Models\ProfissionalModel;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Libraries\Auth;
use \DateTime;

class Profissional extends BaseController
{
    public function initController(
        RequestInterface $request,
        ResponseInterface $response,
        LoggerInterface $logger
    ) {
        parent::initController($request, $response, $logger);
        $this->session = \Config\Services::session();
        $this->usuario = $this->session->get('dadoslogin');
        if($this->usuario == null){
            header('Location: '.base_url());
            exit(); 
        }
		date_default_timezone_set('America/Sao_Paulo');
        $this->profissionalModel = new ProfissionalModel();
        $this->auth = new Auth();
        helper('complementos');
    }


    public function index(){
        $dados = array();
        $dados['resultados'] = $this->profissionalModel->getProfissional();
        echo view('commons/header');	          
        echo view('commons/navbartop');
        echo view('commons/navbarleft', getBarMenu($this->usuario));	
        echo view('profissionais/profissional', $dados);
        echo view('commons/footer');
    }

    public function Inserir(){
        echo view('commons/header');
        echo view('commons/navbartop');
        echo view('commons/navbarleft', getBarMenu($this->usuario));
        echo view('profissionais/profissional_cadastro');
        echo view('commons/footer');
    }

    public function Store(){
        $dados = array();
        $id = $this->request->getPost('profissional_id');
        if($id == ""){
            $dados['NOME_PROFISSIONAL'] = $this->request->getPost('profissional_nome');
            $dados['DATA_NASCIMENTO'] = $this->request->getPost('profissional_data_nascimento');
            $dados['IDADE'] = $this->request->getPost('profissional_idade');
            $dados['SEXO'] = $this->request->getPost('profissional_sexo');
            $dados['NATURALIDADE'] = $this->request->getPost('profissional_naturalidade');
            $dados['ESTADO_NATURALIDADE'] = $this->request->getPost('profissional_estado_naturalidade');
            $dados['ESTADO_CIVIL'] = $this->request->getPost('profissional_estado_civil');
            $dados['CPF'] = $this->request->getPost('profissional_cpf');
            $dados['DATA_EMISSAO'] = $this->request->getPost('profissional_data_emissao');
            $dados['ORGAO_EXPEDITOR'] = $this->request->getPost('profissional_orgao_expeditor');
            $dados['TITULO_ELEITOR'] = $this->request->getPost('profissional_titulo_eleitor');
            $dados['ZONA'] = $this->request->getPost('profissional_zona');
            $dados['SECAO'] = $this->request->getPost('profissional_secao');
            $dados['COR_RACA'] = $this->request->getPost('profissional_cor_raca');
            $dados['FILIACAO_1'] = $this->request->getPost('profissional_filiacao_1');
            $dados['FILIACAO_2'] = $this->request->getPost('profissional_filiacao_2');
            $dados['ENDERECO'] = $this->request->getPost('profissional_endereco');
            $dados['NUMERO'] = $this->request->getPost('profissional_numero');
            $dados['BAIRRO'] = $this->request->getPost('profissional_bairro');
            $dados['CIDADE'] = $this->request->getPost('profissional_cidade');
            $dados['ESTADO'] = $this->request->getPost('profissional_estado');
            $dados['TELEFONE_1'] = $this->request->getPost('profissional_telefone_1');
            $dados['TELEFONE_2'] = $this->request->getPost('profissional_telefone_2');
            $dados['EMAIL'] = $this->request->getPost('profissional_email');
            $dados['ESCOLARIDADE'] = $this->request->getPost('profissional_escolaridade');
            $dados['CURSO_SUPERIOR'] = $this->request->getPost('profissional_curso_superior');
            $dados['NIVEL_GRAU_ACADEMICO'] = $this->request->getPost('profissional_nivel_grau_academico');
            $dados['ESPECIALIZACAO_1'] = $this->request->getPost('profissional_especializacao_1');
            $dados['ESPECIALIZACAO_2'] = $this->request->getPost('profissional_especializacao_2');
            $dados['ESPECIALIZACAO_3'] = $this->request->getPost('profissional_especializacao_3');
            $dados['CARGO'] = $this->request->getPost('profissional_cargo');
            $dados['CARGA_HORARIA'] = $this->request->getPost('profissional_carga_horaria');
            $dados['HORARIO_ENTRADA'] = $this->request->getPost('profissional_horario_entrada');
            $dados['HORARIO_SAIDA'] = $this->request->getPost('profissional_horario_saida');
            $dados['INTERVALO'] = $this->request->getPost('profissional_intervalo');
            $dados['INTERVALO_HORA'] = $this->request->getPost('profissional_intervalo_hora');
            $dados['TIPO_VINCULO'] = $this->request->getPost('profissional_tipo_vinculo');
            $dados['DATA_ADMISSAO'] = $this->request->getPost('profissional_data_admissao');
            $dados['DATA_DESLIGAMENTO'] = $this->request->getPost('profissional_data_desligamento');

            $arquivo = $this->request->getFile('profissional_imagem');

            if($arquivo != "" && $arquivo != null){
                $input = $this->validate([
                    'file' => [
                        'uploaded[profissional_imagem]',
                        'mime_in[profissional_imagem,image/jpg,image/jpeg,image/png]',
                        'max_size[profissional_imagem,2048]',
                    ]
                ]);
                    
                if (!$input) {
                    return redirect()->to('/Profissional/index?tipo_msg=erro&msg=Arquivo inválido!');
                } else {
                    $img = $this->request->getFile('profissional_imagem');
    
                    $nome_aleatorio = $img->getRandomName();
                    $img->move($_SERVER['DOCUMENT_ROOT'].'/uploads',$nome_aleatorio);
    
                    $dados['NOME_ALEATORIO'] = $nome_aleatorio;        
                }
            }

            $insert_id = $this->profissionalModel->setProfissional($dados);

            if($insert_id){
                return redirect()->to('/Profissional/index?tipo_msg=sucesso&msg=Ação realizada!');
            }else{
                return redirect()->to('/Profissional/index?tipo_msg=erro&msg=Erro ao realizar ação!');
            }
        }else{
            $dados['ID_PROFISSIONAL'] = $this->request->getPost('profissional_id');
            $dados['NOME_PROFISSIONAL'] = $this->request->getPost('profissional_nome');
            $dados['DATA_NASCIMENTO'] = $this->request->getPost('profissional_data_nascimento');
            $dados['IDADE'] = $this->request->getPost('profissional_idade');
            $dados['SEXO'] = $this->request->getPost('profissional_sexo');
            $dados['NATURALIDADE'] = $this->request->getPost('profissional_naturalidade');
            $dados['ESTADO_NATURALIDADE'] = $this->request->getPost('profissional_estado_naturalidade');
            $dados['ESTADO_CIVIL'] = $this->request->getPost('profissional_estado_civil');
            $dados['CPF'] = $this->request->getPost('profissional_cpf');
            $dados['DATA_EMISSAO'] = $this->request->getPost('profissional_data_emissao');
            $dados['ORGAO_EXPEDITOR'] = $this->request->getPost('profissional_orgao_expeditor');
            $dados['TITULO_ELEITOR'] = $this->request->getPost('profissional_titulo_eleitor');
            $dados['ZONA'] = $this->request->getPost('profissional_zona');
            $dados['SECAO'] = $this->request->getPost('profissional_secao');
            $dados['COR_RACA'] = $this->request->getPost('profissional_cor_raca');
            $dados['FILIACAO_1'] = $this->request->getPost('profissional_filiacao_1');
            $dados['FILIACAO_2'] = $this->request->getPost('profissional_filiacao_2');
            $dados['ENDERECO'] = $this->request->getPost('profissional_endereco');
            $dados['NUMERO'] = $this->request->getPost('profissional_numero');
            $dados['BAIRRO'] = $this->request->getPost('profissional_bairro');
            $dados['CIDADE'] = $this->request->getPost('profissional_cidade');
            $dados['ESTADO'] = $this->request->getPost('profissional_estado');
            $dados['TELEFONE_1'] = $this->request->getPost('profissional_telefone_1');
            $dados['TELEFONE_2'] = $this->request->getPost('profissional_telefone_2');
            $dados['EMAIL'] = $this->request->getPost('profissional_email');
            $dados['ESCOLARIDADE'] = $this->request->getPost('profissional_escolaridade');
            $dados['CURSO_SUPERIOR'] = $this->request->getPost('profissional_curso_superior');
            $dados['NIVEL_GRAU_ACADEMICO'] = $this->request->getPost('profissional_nivel_grau_academico');
            $dados['ESPECIALIZACAO_1'] = $this->request->getPost('profissional_especializacao_1');
            $dados['ESPECIALIZACAO_2'] = $this->request->getPost('profissional_especializacao_2');
            $dados['ESPECIALIZACAO_3'] = $this->request->getPost('profissional_especializacao_3');
            $dados['CARGO'] = $this->request->getPost('profissional_cargo');
            $dados['CARGA_HORARIA'] = $this->request->getPost('profissional_carga_horaria');
            $dados['HORARIO_ENTRADA'] = $this->request->getPost('profissional_horario_entrada');
            $dados['HORARIO_SAIDA'] = $this->request->getPost('profissional_horario_saida');
            $dados['INTERVALO'] = $this->request->getPost('profissional_intervalo');
            $dados['INTERVALO_HORA'] = $this->request->getPost('profissional_intervalo_hora');
            $dados['TIPO_VINCULO'] = $this->request->getPost('profissional_tipo_vinculo');
            $dados['DATA_ADMISSAO'] = $this->request->getPost('profissional_data_admissao');
            $dados['DATA_DESLIGAMENTO'] = $this->request->getPost('profissional_data_desligamento');


            $arquivo = $this->request->getFile('profissional_imagem');

            if($arquivo != "" && $arquivo != null){
                $input = $this->validate([
                    'file' => [
                        'uploaded[profissional_imagem]',
                        'mime_in[profissional_imagem,image/jpg,image/jpeg,image/png]',
                        'max_size[profissional_imagem,2048]',
                    ]
                ]);
                    
                if (!$input) {
                    return redirect()->to('/Profissional/index?tipo_msg=erro&msg=Arquivo inválido!');
                } else {
                    $img = $this->request->getFile('profissional_imagem');
    
                    $nome_aleatorio = $img->getRandomName();
                    $img->move($_SERVER['DOCUMENT_ROOT'].'/uploads',$nome_aleatorio);
    
                    $dados['NOME_ALEATORIO'] = $nome_aleatorio;        
                }
            }
            
            if($this->profissionalModel->updateProfissional($dados)){
                return redirect()->to('/Profissional/index?tipo_msg=sucesso&msg=Ação realizada!');
            }else{
                return redirect()->to('/Profissional/index?tipo_msg=erro&msg=Erro ao realizar ação!');
            }

        }
    }

    public function Editar($id=""){
        $dados['profissional'] = $this->profissionalModel->getProfissionalID(base64_decode($id));
        echo view('commons/header');
        echo view('commons/navbartop');
        echo view('commons/navbarleft', getBarMenu($this->usuario));
        echo view('profissionais/profissional_cadastro', $dados);
        echo view('commons/footer');
    }

    public function Excluir($id=""){
        if($this->profissionalModel->deleteProfissional(base64_decode($id))){
            return redirect()->to('/Profissional/index?tipo_msg=sucesso&msg=Ação realizada!');
        }else{
            return redirect()->to('/Profissional/index?tipo_msg=erro&msg=Erro ao realizar ação!');
        }
    }
}
