<?php namespace App\Models;

use CodeIgniter\Model;

class EscolaModel extends Model {

    protected $table = 'CAD_ESCOLA';

    public function __construct(){
        $this->db      = \Config\Database::connect();
        $this->builder = $this->db->table('CAD_ESCOLA');
        $this->session = \Config\Services::session();
        $this->usuario = $this->session->get('dadoslogin');
    }

    function getEscolas(){
        $builder = $this->db->table('CAD_ESCOLA');
        return $builder->get()->getResult();
    }
}