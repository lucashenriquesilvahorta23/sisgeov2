<?php namespace App\Models;

use CodeIgniter\Model;

class AlunoModel extends Model{

    protected $table = 'CAD_ALUNO';

    public function __construct(){
        $this->db      = \Config\Database::connect();
        $this->builder = $this->db->table('CAD_ALUNO');
    }

    function getAluno(){
        $this->builder->orderBy('NOME_ALUNO',' ASC');
        return $this->builder->get()->getResult();
    }

    function getAlunoID($id){
        $this->builder->where('ID_ALUNO', $id);
        return $this->builder->get()->getRow();
    }

    function getDeficiencia($id){
        $builder = $this->db->table('CAD_ALUNO_DEFICIENCIA');
        $builder->where('FK_ID_ALUNO', $id);
        return $builder->get()->getRow();
    }

    function getTranstorno($id){
        $builder = $this->db->table('CAD_ALUNO_TRANSTORNO');
        $builder->where('FK_ID_ALUNO', $id);
        return $builder->get()->getRow();
    }

    function getDoenca($id){
        $builder = $this->db->table('CAD_ALUNO_CRONICA');
        $builder->where('FK_ID_ALUNO', $id);
        return $builder->get()->getRow();
    }

    function setAluno($dados){
        $builder = $this->db->table('CAD_ALUNO');
        $builder->insert($dados);
        $id = $this->db->insertID();
        return $id;
    }

    function setDeficiencia($dados){
        $builder = $this->db->table('CAD_ALUNO_DEFICIENCIA');
        $builder->insert($dados);
        $id = $this->db->insertID();
        return $id;
    }

    function setTranstorno($dados){
        $builder = $this->db->table('CAD_ALUNO_TRANSTORNO');
        $builder->insert($dados);
        $id = $this->db->insertID();
        return $id;
    }

    function setDoencaCronica($dados){
        $builder = $this->db->table('CAD_ALUNO_CRONICA');
        $builder->insert($dados);
        $id = $this->db->insertID();
        return $id;
    }

    function updateAluno($dados){
        $builder = $this->db->table('CAD_ALUNO');
        $builder->where('ID_ALUNO', $dados['ID_ALUNO']);
        $builder->update($dados);
        return $this->db->affectedRows();
    }

    function deleteDeficiencia($id){
        $builder = $this->db->table('CAD_ALUNO_DEFICIENCIA');
        $builder->where('FK_ID_ALUNO', $id)->delete();
        return $this->db->affectedRows();
    }

    function deleteTranstorno($id){
        $builder = $this->db->table('CAD_ALUNO_TRANSTORNO');
        $builder->where('FK_ID_ALUNO', $id)->delete();
        return $this->db->affectedRows();
    }

    function deleteDoencaCronica($id){
        $builder = $this->db->table('CAD_ALUNO_CRONICA');
        $builder->where('FK_ID_ALUNO', $id)->delete();
        return $this->db->affectedRows();
    }

    function deleteAluno($id){
        $this->builder->where('ID_ALUNO', $id)->delete();
        return $this->db->affectedRows();
    }
}
?>