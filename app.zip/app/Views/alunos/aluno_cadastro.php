 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Aluno
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Aluno</a></li>
        <li class="breadcrumb-item active"><?php echo isset($aluno->ID_ALUNO) ? 'Edição' : 'Cadastro';?> de aluno</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
        <div class="row">	
            <div class="col-lg-12 col-12">
                    <div class="box box-solid bg-login">
                    <div class="box-header with-border">
                        <h4 class="box-title"><?php echo isset($aluno->ID_ALUNO) ? 'Edição' : 'Cadastro';?> de aluno</h4>			
                        <ul class="box-controls pull-right">
                            <li><a class="box-btn-close" href="#"></a></li>
                            <li><a class="box-btn-slide" href="#"></a></li>	
                            <li><a class="box-btn-fullscreen" href="#"></a></li>
                        </ul>
                    </div>
                    <!-- /.box-header -->
                    <form novalidate method="POST" action="/Aluno/Store" id="frmCliente_cadastro" class="validate" enctype='multipart/form-data'>
                        <div class="box-body">
                            <!-- Linha 1 -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Código</label>
                                        <input disabled="disabled" type="text" class="form-control" value="<?php echo isset($aluno->ID_ALUNO) ? $aluno->ID_ALUNO : '';?>" >
                                        <input type="hidden" class="form-control" value="<?php echo isset($aluno->ID_ALUNO) ? $aluno->ID_ALUNO : '';?>" name="aluno_id">
                                    </div>
                                </div>
                                <div class="col-md-3">                      
                                    <div class="form-group">
                                        <label>Foto Aluno</label>
                                        <div class="controls">
                                            <input type="file" name="aluno_imagem" id="aluno_imagem" class="form-control">
                                        </div>
                                        <p >Foto do aluno<br> <?php if(isset($aluno->NOME_ALEATORIO)){echo '<a style="color: #000;" target="_blank" href="'.LINK_UPLOAD.$aluno->NOME_ALEATORIO.'">Clique para ver a imagem</a>';}?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>NIS aluno *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->NIS_ALUNO) ? $aluno->NIS_ALUNO : '';?>" name="aluno_nis" required>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Nome do aluno *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->NOME_ALUNO) ? $aluno->NOME_ALUNO : '';?>" name="aluno_nome" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Data de nascimento *</label>
                                        <input type="date" class="form-control" value="<?php echo isset($aluno->DATA_NASCIMENTO) ? $aluno->DATA_NASCIMENTO : '';?>" name="aluno_data_nascimento" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 2 -->
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Idade *</label>
                                        <input type="number" class="form-control" value="<?php echo isset($aluno->IDADE) ? $aluno->IDADE : '';?>" name="aluno_idade" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Sexo *</label>
                                        <select class="form-control" name="aluno_sexo" required>
                                            <option <?php if(isset($aluno->SEXO) && $aluno->SEXO == 'M'){echo 'selected';}?> value="M">Masculino</option>
                                            <option <?php if(isset($aluno->SEXO) && $aluno->SEXO == 'F'){echo 'selected';}?> value="F">Feminino</option>
                                            <option <?php if(isset($aluno->SEXO) && $aluno->SEXO == 'O'){echo 'selected';}?> value="O">Outro</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Naturalidade *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->NATURALIDADE) ? $aluno->NATURALIDADE : '';?>" name="aluno_naturalidade" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Estado *</label>
                                        <select class="form-control" name="aluno_estado_naturalidade" required>
                                            <option value="AC" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'AC'){echo 'selected';}?> >Acre (AC)</option>
                                            <option value="AL" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'AL'){echo 'selected';}?> >Alagoas (AL)</option>
                                            <option value="AP" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'AP'){echo 'selected';}?> >Amapá (AP)</option>
                                            <option value="AM" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'AM'){echo 'selected';}?> >Amazonas (AM)</option>
                                            <option value="BA" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'BA'){echo 'selected';}?> >Bahia (BA)</option>
                                            <option value="CE" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'CE'){echo 'selected';}?> >Ceará (CE)</option>
                                            <option value="DF" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'DF'){echo 'selected';}?> >Distrito Federal (DF)</option>
                                            <option value="ES" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'ES'){echo 'selected';}?> >Espírito Santo (ES)</option>
                                            <option value="GO" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'GO'){echo 'selected';}?> >Goiás (GO)</option>
                                            <option value="MA" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'MA'){echo 'selected';}?> >Maranhão (MA)</option>
                                            <option value="MT" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'MT'){echo 'selected';}?> >Mato Grosso (MT)</option>
                                            <option value="MS" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'MS'){echo 'selected';}?> >Mato Grosso do Sul (MS)</option>
                                            <option value="MG" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'MG'){echo 'selected';}?> >Minas Gerais (MG)</option>
                                            <option value="PA" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'PA'){echo 'selected';}?> >Pará (PA)</option>
                                            <option value="PB" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'PB'){echo 'selected';}?> >Paraíba (PB)</option>
                                            <option value="PR" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'PR'){echo 'selected';}?> >Paraná (PR)</option>
                                            <option value="PE" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'PE'){echo 'selected';}?> >Pernambuco (PE)</option>
                                            <option value="PI" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'PI'){echo 'selected';}?> >Piauí (PI)</option>
                                            <option value="RJ" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'RJ'){echo 'selected';}?> >Rio de Janeiro (RJ)</option>
                                            <option value="RN" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'RN'){echo 'selected';}?> >Rio Grande do Norte (RN)</option>
                                            <option value="RS" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'RS'){echo 'selected';}?> >Rio Grande do Sul (RS)</option>
                                            <option value="RO" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'RO'){echo 'selected';}?> >Rondônia (RO)</option>
                                            <option value="RR" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'RR'){echo 'selected';}?> >Roraima (RR)</option>
                                            <option value="SC" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'SC'){echo 'selected';}?> >Santa Catarina (SC)</option>
                                            <option value="SP" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'SP'){echo 'selected';}?> >São Paulo (SP)</option>
                                            <option value="SE" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'SE'){echo 'selected';}?> >Sergipe (SE)</option>
                                            <option value="TO" <?php if(isset($aluno->ESTADO_NATURALIDADE) && $aluno->ESTADO_NATURALIDADE == 'TO'){echo 'selected';}?> >Tocantins (TO)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 3 -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nacionalidade *</label>
                                        <select name="aluno_nacionalidade" required id="aluno_nacionalidade" class="form-control">
                                            <option <?php if(isset($aluno->NACIONALIDADE) && $aluno->NACIONALIDADE == 'BR'){echo 'selected';}?> value="BR">Brasileiro</option>
                                            <option <?php if(isset($aluno->NACIONALIDADE) && $aluno->NACIONALIDADE == 'OT'){echo 'selected';}?> value="OT">Outro</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>CPF *</label>
                                        <input type="text" class="form-control cpf"  value="<?php echo isset($aluno->CPF) ? $aluno->CPF : '';?>" name="aluno_cpf" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Data de emissão *</label>
                                        <input type="date" class="form-control"  value="<?php echo isset($aluno->DATA_EMISSAO) ? $aluno->DATA_EMISSAO : '';?>" name="aluno_data_emissao" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 4 -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Orgão expeditor *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno->ORGAO_EXPEDITOR) ? $aluno->ORGAO_EXPEDITOR : '';?>" name="aluno_orgao_expeditor" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Número da matrícula (certidão de nascimento) *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno->NUMERO_MATRICULA) ? $aluno->NUMERO_MATRICULA : '';?>" name="aluno_numero_matricula" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Cor ou Raça *</label>
                                        <select class="form-control" name="aluno_cor_raca" required>
                                            <option <?php if(isset($aluno->COR_RACA) && $aluno->COR_RACA == 'BR'){echo 'selected';}?> value="BR">Branco</option>
                                            <option <?php if(isset($aluno->COR_RACA) && $aluno->COR_RACA == 'AM'){echo 'selected';}?> value="AM">Amarelo</option>
                                            <option <?php if(isset($aluno->COR_RACA) && $aluno->COR_RACA == 'IN'){echo 'selected';}?> value="IN">Indigena</option>
                                            <option <?php if(isset($aluno->COR_RACA) && $aluno->COR_RACA == 'NG'){echo 'selected';}?> value="NG">Negro</option>
                                            <option <?php if(isset($aluno->COR_RACA) && $aluno->COR_RACA == 'PD'){echo 'selected';}?> value="PD">Pardo</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 5 - Filiação 1 -->
                            <h5>Filiação 1</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno->FILIACAO_1) ? $aluno->FILIACAO_1 : '';?>" name="aluno_filiacao_1" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Situação *</label>
                                        <select class="form-control" name="aluno_filiacao_1_vivo" required>
                                            <option <?php if(isset($aluno->FILIACAO_1_VIVO) && $aluno->FILIACAO_1_VIVO == 'V'){echo 'selected';}?> value="V">Vivo</option>
                                            <option <?php if(isset($aluno->FILIACAO_1_VIVO) && $aluno->FILIACAO_1_VIVO == 'F'){echo 'selected';}?> value="F">Falecido</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Telefone *</label>
                                        <input type="text" class="form-control telefone"  value="<?php echo isset($aluno->FILIACAO_1_TELEFONE) ? $aluno->FILIACAO_1_TELEFONE : '';?>" name="aluno_filiacao_1_telefone" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Profissão *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno->FILIACAO_1_PROFISSAO) ? $aluno->FILIACAO_1_PROFISSAO : '';?>" name="aluno_filiacao_1_profissao" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 6 - Filiação 2 -->
                            <h5>Filiação 2</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->FILIACAO_2) ? $aluno->FILIACAO_2 : '';?>" name="aluno_filiacao_2" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Situação *</label>
                                        <select class="form-control" name="aluno_filiacao_2_vivo" required>
                                            <option <?php if(isset($aluno->FILIACAO_2_VIVO) && $aluno->FILIACAO_2_VIVO == 'V'){echo 'selected';}?> value="V">Vivo</option>
                                            <option <?php if(isset($aluno->FILIACAO_2_VIVO) && $aluno->FILIACAO_2_VIVO == 'F'){echo 'selected';}?> value="F">Falecido</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Telefone *</label>
                                        <input type="text" class="form-control telefone" value="<?php echo isset($aluno->FILIACAO_2_TELEFONE) ? $aluno->FILIACAO_2_TELEFONE : '';?>" name="aluno_filiacao_2_telefone" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Profissão *</label>
                                        <input type="text" class="form-control telefone" value="<?php echo isset($aluno->FILIACAO_2_PROFISSAO) ? $aluno->FILIACAO_2_PROFISSAO : '';?>" name="aluno_filiacao_2_profissao" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 7 - Responsável legal -->
                            <h5>Responsável legal</h5>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Situação *</label>
                                        <select class="form-control" name="aluno_responsavel_legal" required>
                                            <option value="O">Outro</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->RESPONSAVEL_LEGAL_NOME) ? $aluno->RESPONSAVEL_LEGAL_NOME : '';?>" name="aluno_responsavel_legal_nome" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Grau de parentesco *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->GRAU_PARENTESCO) ? $aluno->GRAU_PARENTESCO : '';?>" name="aluno_grau_parentesco" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Telefone *</label>
                                        <input type="text" class="form-control telefone" value="<?php echo isset($aluno->RESPONSAVEL_LEGAL_TELEFONE) ? $aluno->RESPONSAVEL_LEGAL_TELEFONE : '';?>" name="aluno_responsavel_legal_telefone" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Profissão *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->RESPONSAVEL_LEGAL_PROFISSAO) ? $aluno->RESPONSAVEL_LEGAL_PROFISSAO : '';?>" name="aluno_responsavel_legal_profissao" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 8 - Endereço -->
                            <h5>Endereço</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Endereço *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->ENDERECO) ? $aluno->ENDERECO : '';?>" name="aluno_endereco" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->NUMERO) ? $aluno->NUMERO : '';?>" name="aluno_numero" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bairro *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->BAIRRO) ? $aluno->BAIRRO : '';?>" name="aluno_bairro" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($aluno->CIDADE) ? $aluno->CIDADE : '';?>" name="aluno_cidade" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Estado *</label>
                                        <select class="form-control" name="aluno_estado" required>
                                            <option value="AC" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'AC'){echo 'selected';}?> >Acre (AC)</option>
                                            <option value="AL" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'AL'){echo 'selected';}?> >Alagoas (AL)</option>
                                            <option value="AP" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'AP'){echo 'selected';}?> >Amapá (AP)</option>
                                            <option value="AM" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'AM'){echo 'selected';}?> >Amazonas (AM)</option>
                                            <option value="BA" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'BA'){echo 'selected';}?> >Bahia (BA)</option>
                                            <option value="CE" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'CE'){echo 'selected';}?> >Ceará (CE)</option>
                                            <option value="DF" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'DF'){echo 'selected';}?> >Distrito Federal (DF)</option>
                                            <option value="ES" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'ES'){echo 'selected';}?> >Espírito Santo (ES)</option>
                                            <option value="GO" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'GO'){echo 'selected';}?> >Goiás (GO)</option>
                                            <option value="MA" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'MA'){echo 'selected';}?> >Maranhão (MA)</option>
                                            <option value="MT" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'MT'){echo 'selected';}?> >Mato Grosso (MT)</option>
                                            <option value="MS" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'MS'){echo 'selected';}?> >Mato Grosso do Sul (MS)</option>
                                            <option value="MG" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'MG'){echo 'selected';}?> >Minas Gerais (MG)</option>
                                            <option value="PA" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'PA'){echo 'selected';}?> >Pará (PA)</option>
                                            <option value="PB" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'PB'){echo 'selected';}?> >Paraíba (PB)</option>
                                            <option value="PR" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'PR'){echo 'selected';}?> >Paraná (PR)</option>
                                            <option value="PE" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'PE'){echo 'selected';}?> >Pernambuco (PE)</option>
                                            <option value="PI" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'PI'){echo 'selected';}?> >Piauí (PI)</option>
                                            <option value="RJ" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'RJ'){echo 'selected';}?> >Rio de Janeiro (RJ)</option>
                                            <option value="RN" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'RN'){echo 'selected';}?> >Rio Grande do Norte (RN)</option>
                                            <option value="RS" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'RS'){echo 'selected';}?> >Rio Grande do Sul (RS)</option>
                                            <option value="RO" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'RO'){echo 'selected';}?> >Rondônia (RO)</option>
                                            <option value="RR" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'RR'){echo 'selected';}?> >Roraima (RR)</option>
                                            <option value="SC" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'SC'){echo 'selected';}?> >Santa Catarina (SC)</option>
                                            <option value="SP" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'SP'){echo 'selected';}?> >São Paulo (SP)</option>
                                            <option value="SE" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'SE'){echo 'selected';}?> >Sergipe (SE)</option>
                                            <option value="TO" <?php if(isset($aluno->ESTADO) && $aluno->ESTADO == 'TO'){echo 'selected';}?> >Tocantins (TO)</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <br>


                            <!-- Linha de deficiência -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Possui deficiência *</label>
                                        <select class="form-control" name="aluno_possui_deficiencia" required>
                                            <option <?php if(isset($aluno->POSSUI_DEFICIENCIA) && $aluno->POSSUI_DEFICIENCIA == 'N'){echo 'selected';}?>  value="N">Não</option>
                                            <option <?php if(isset($aluno->POSSUI_DEFICIENCIA) && $aluno->POSSUI_DEFICIENCIA == 'S'){echo 'selected';}?>  value="S">Sim</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_baixa_visao" value="S" aria-invalid="false" name="aluno_baixa_visao" <?php if(isset($aluno_deficiencia->BAIXA_VISAO) && $aluno_deficiencia->BAIXA_VISAO == "S"){echo "checked";}?>>
                                        <label for="aluno_baixa_visao">Baixa visão</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_deficiencia_fisica" value="S" aria-invalid="false" name="aluno_deficiencia_fisica" <?php if(isset($aluno_deficiencia->DEFICIENCIA_FISICA) && $aluno_deficiencia->DEFICIENCIA_FISICA == "S"){echo "checked";}?>>
                                        <label for="aluno_deficiencia_fisica">Deficiência física</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_surdocegueira" value="S" aria-invalid="false" name="aluno_surdocegueira" <?php if(isset($aluno_deficiencia->SURDOCEGUEIRA) && $aluno_deficiencia->SURDOCEGUEIRA == "S"){echo "checked";}?>>
                                        <label for="aluno_surdocegueira">Surdocegueira</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_cegueira" value="S" aria-invalid="false" name="aluno_cegueira" <?php if(isset($aluno_deficiencia->CEGUEIRA) && $aluno_deficiencia->CEGUEIRA == "S"){echo "checked";}?>>
                                        <label for="aluno_cegueira">Cegueira</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_intelectual" value="S" aria-invalid="false" name="aluno_intelectual" <?php if(isset($aluno_deficiencia->INTELECTUAL) && $aluno_deficiencia->INTELECTUAL == "S"){echo "checked";}?>>
                                        <label for="aluno_intelectual">Deficiência intelectual</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_multipla" value="S" aria-invalid="false" name="aluno_multipla" <?php if(isset($aluno_deficiencia->MULTIPLA) && $aluno_deficiencia->MULTIPLA == "S"){echo "checked";}?>>
                                        <label for="aluno_multipla">Deficiência múltipla</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_auditiva" value="S" aria-invalid="false" name="aluno_auditiva" <?php if(isset($aluno_deficiencia->AUDITIVA) && $aluno_deficiencia->AUDITIVA == "S"){echo "checked";}?>>
                                        <label for="aluno_auditiva">Deficiência auditiva</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="surdez" value="S" aria-invalid="false" name="surdez" <?php if(isset($aluno_deficiencia->SURDEZ) && $aluno_deficiencia->SURDEZ == "S"){echo "checked";}?>>
                                        <label for="surdez">Surdez</label>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="form-check">
                                        <label class="form-check-label">Outros </label>
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno_deficiencia->OUTROS) ? $aluno_deficiencia->OUTROS : '';?>" name="aluno_outros" required>
                                    </div>
                                </div>
                            </div>
                            <br>


                            <!-- Linha de transtorno -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Possui transtorno *</label>
                                        <select class="form-control" name="aluno_possui_transtorno" required>
                                            <option <?php if(isset($aluno->POSSUI_TRANSTORNO) && $aluno->POSSUI_TRANSTORNO == 'N'){echo 'selected';}?>  value="N">Não</option>
                                            <option <?php if(isset($aluno->POSSUI_TRANSTORNO) && $aluno->POSSUI_TRANSTORNO == 'S'){echo 'selected';}?>  value="S">Sim</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_autismo" value="S" aria-invalid="false" name="aluno_autismo" <?php if(isset($aluno_transtorno->AUSTISMO) && $aluno_transtorno->AUSTISMO == "S"){echo "checked";}?>>
                                        <label for="aluno_autismo">Transtorno espectro autista</label>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_tdah" value="S" aria-invalid="false" name="aluno_tdah" <?php if(isset($aluno_transtorno->TDAH) && $aluno_transtorno->TDAH == "S"){echo "checked";}?>>
                                        <label for="aluno_tdah">TDAH</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno_transtorno->OUTROS) ? $aluno_transtorno->OUTROS : '';?>" name="aluno_outros_transtornos" required>
                                        <label for="aluno_outros_transtornos">Outros</label>
                                    </div>
                                </div>
                            </div>

                            <br>

                            <!-- Linha de doenças crônicas -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Possui doenças crônicas *</label>
                                        <select class="form-control" name="aluno_possui_doencas_cronicas" required>
                                            <option <?php if(isset($aluno->POSSUI_DOENCAS_CRONICAS) && $aluno->POSSUI_DOENCAS_CRONICAS == 'N'){echo 'selected';}?>  value="N">Não</option>
                                            <option <?php if(isset($aluno->POSSUI_DOENCAS_CRONICAS) && $aluno->POSSUI_DOENCAS_CRONICAS == 'S'){echo 'selected';}?>  value="S">Sim</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_diabete" value="S" aria-invalid="false" name="aluno_diabete" <?php if(isset($aluno_doencas_cronicas->DIEABETE) && $aluno_doencas_cronicas->DIEABETE == "S"){echo "checked";}?>>
                                        <label for="aluno_diabete">Diabetes Mellitus</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_respiratoria" value="S" aria-invalid="false" name="aluno_respiratoria" <?php if(isset($aluno_doencas_cronicas->RESPIRATORIA) && $aluno_doencas_cronicas->RESPIRATORIA == "S"){echo "checked";}?>>
                                        <label for="aluno_respiratoria">Respiratória</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_neurologia" value="S" aria-invalid="false" name="aluno_neurologia" <?php if(isset($aluno_doencas_cronicas->NEUROLOGIA) && $aluno_doencas_cronicas->NEUROLOGIA == "S"){echo "checked";}?>>
                                        <label for="aluno_neurologia">Neurológica</label>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-check">
                                        <input type="checkbox" id="aluno_obesidade" value="S" aria-invalid="false" name="aluno_obesidade" <?php if(isset($aluno_doencas_cronicas->OBESIDADE) && $aluno_doencas_cronicas->OBESIDADE == "S"){echo "checked";}?>>
                                        <label for="aluno_obesidade">Obesidade</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input type="text" class="form-control"  value="<?php echo isset($aluno_doencas_cronicas->OUTROS) ? $aluno_doencas_cronicas->OUTROS : '';?>" name="aluno_outros_cronicas" required>
                                        <label class="form-check-label">Outros </label>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Possui superdotação *</label>
                                        <select class="form-control" name="aluno_possui_superdotacao" required>
                                            <option <?php if(isset($aluno->POSSUI_SUPERDOTACAO) && $aluno->POSSUI_SUPERDOTACAO == 'N'){echo 'selected';}?>  value="N">Não</option>
                                            <option <?php if(isset($aluno->POSSUI_SUPERDOTACAO) && $aluno->POSSUI_SUPERDOTACAO == 'S'){echo 'selected';}?>  value="S">Sim</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-right">
                            <button type="submit" class="btn btn-warning btn-outline mr-1">
                                <i class="fa fa-times"></i> Cancelar
                            </button>
                            <button type="submit" class="btn btn-primary btn-outline">
                                <i class="fa fa-save"></i> Salvar
                            </button>
                        </div>  
                    </form>
                    </div>
                    <!-- /.box -->			
            </div>  
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script src="/template/js/escola.js"></script>