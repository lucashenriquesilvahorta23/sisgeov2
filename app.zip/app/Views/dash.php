<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
	  <div class="row">
		<div class="col-xl-3 col-md-6 col-12 ">
          	<div class="box">
              <div class="box-body">
                <div class="flexbox">
                  <h5>Visits</h5>
                  <div class="dropdown">
                    <span role="button" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Monthly</span>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a class="dropdown-item" href="#"><i class="ion-android-list"></i> Details</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-add"></i> Add new</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-refresh"></i> Refresh</a>
                    </div>
                  </div>
                </div>

                <div class="text-left my-2">
                  <div class="font-size-30 mb-15">2 125 854 <small class="font-size-14 text-success">+5% <i class="fa fa-arrow-up"></i></small></div>
                  <div id="linechart"></div>
                </div>
              </div>
            </div>
        </div>
		<div class="col-xl-3 col-md-6 col-12 ">
          	<div class="box">
              <div class="box-body">
                <div class="flexbox">
                  <h5>Orders</h5>
                  <div class="dropdown">
                    <span role="button" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Weekly</span>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a class="dropdown-item" href="#"><i class="ion-android-list"></i> Details</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-add"></i> Add new</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-refresh"></i> Refresh</a>
                    </div>
                  </div>
                </div>

                <div class="text-left my-2">
                  <div class="font-size-30 mb-15">$421 458.45 <small class="font-size-14 text-danger">-21% <i class="fa fa-arrow-down"></i></small></div>
                  <div id="linechart2"></div>
                </div>
              </div>
            </div>
        </div>
		<div class="col-xl-3 col-md-6 col-12 ">
          	<div class="box">
              <div class="box-body">
                <div class="flexbox">
                  <h5>Top Advertisers</h5>
                  <div class="dropdown">
                    <span role="button" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Weekly</span>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a class="dropdown-item" href="#"><i class="ion-android-list"></i> Details</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-add"></i> Add new</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-refresh"></i> Refresh</a>
                    </div>
                  </div>
                </div>

                <div class="flexbox text-left my-2">					
                  <div class="donut" data-peity='{ "fill": ["#28D094", "#1E9FF2", "#FF9149"], "radius": 45, "innerRadius": 20  }' >9,6,5</div>
				  <div>
					  <p class="mb-5">
						  <span class="badge badge-dot badge-lg mr-1" style="background-color: #28D094"></span>
                      	  <span>Mobile</span>
					  </p>
					  <p class="mb-5">
						  <span class="badge badge-dot badge-lg mr-1" style="background-color: #1E9FF2"></span>
                      	  <span>TV</span>
					  </p>
					  <p class="mb-5">
						  <span class="badge badge-dot badge-lg mr-1" style="background-color: #FF9149"></span>
                      	  <span>AC</span>
					  </p>					  
				  </div>
                </div>
              </div>
            </div>
        </div>
		<div class="col-xl-3 col-md-6 col-12 ">
          	<div class="box">
              <div class="box-body">
                <div class="flexbox">
                  <h5>Daily Sale</h5>
                  <div class="dropdown">
                    <span role="button" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Today</span>
                    <div class="dropdown-menu dropdown-menu-right">
                      <a class="dropdown-item" href="#"><i class="ion-android-list"></i> Details</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-add"></i> Add new</a>
                      <a class="dropdown-item" href="#"><i class="ion-android-refresh"></i> Refresh</a>
                    </div>
                  </div>
                </div>

                <div class="flexbox text-left my-2">					
                  <div class="bar" data-peity='{ "fill": ["#666EE8", "#FF4961", "#1E9FF2"], "height": 90, "width": 90, "padding":0.2 }'>8952,7458,3254</div>
				  <div>
					  <p class="mb-5">
						  <span class="badge badge-dot badge-lg mr-1" style="background-color: #666EE8"></span>
                      	  <span>Abu Dhabi</span>
					  </p>
					  <p class="mb-5">
						  <span class="badge badge-dot badge-lg mr-1" style="background-color: #FF4961"></span>
                      	  <span>Miami</span>
					  </p>
					  <p class="mb-5">
						  <span class="badge badge-dot badge-lg mr-1" style="background-color: #1E9FF2"></span>
                      	  <span>London</span>
					  </p>					  
				  </div>
                </div>
              </div>
            </div>
        </div>
	  </div>
		
      <div class="row">
		  
        <div class="col-12 col-lg-8">
          <!-- AREA CHART -->
          <div class="box">
            <div class="box-header with-border">
              <h4 class="box-title">Traffic Sources</h4>
				
              <ul class="box-controls pull-right">
			  	<li><a class="box-btn-close" href="#"></a></li>
			  	<li><a class="box-btn-slide" href="#"></a></li>	
			  	<li><a class="box-btn-fullscreen" href="#"></a></li>
			  </ul>
            </div>
            <div class="box-body chart-responsive">
				<div class="flexbox">
					<div>
						<button type="button" class="btn btn-sm btn-rounded btn-primary mr-10 mb-5">Last Year</button>
						<button type="button" class="btn btn-sm btn-rounded btn-outline btn-success mr-10 mb-5">Last Month</button>
						<button type="button" class="btn btn-sm btn-rounded btn-outline btn-danger mr-10 mb-5">Last Week</button>
					</div>
					<div>
						<span class="mr-5"><span class="badge badge-ring badge-primary mr-5"></span>Direct</span>
						<span class="mr-5"><span class="badge badge-ring badge-info mr-5"></span>Referrals</span>
						<span class="mr-5"><span class="badge badge-ring badge-danger mr-5"></span>Search</span>
						<span class="mr-5"><span class="badge badge-ring badge-warning mr-5"></span>Social</span>
					</div>
				</div>
				
                <div class="chart" id="morris_extra_line_chart" style="height: 287px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>	
		
		<div class="col-lg-4 col-12">
			<!-- TO DO List -->
			  <div class="box box-solid box-warning">
				<div class="box-header with-border">
				  <i class="ion ion-clipboard"></i>
				  <h4 class="box-title">To Do List</h4>
				    <ul class="box-controls pull-right">
					  <li><a class="box-btn-close" href="#"></a></li>
					  <li><a class="box-btn-slide" href="#"></a></li>	
					  <li><a class="box-btn-fullscreen" href="#"></a></li>
					</ul>
				</div>
				<!-- /.box-header -->
				<div class="box-body">
				  <ul class="todo-list">
					<li>
					  <!-- drag handle -->
					  <span class="handle">
							<i class="fa fa-ellipsis-v"></i>
							<i class="fa fa-ellipsis-v"></i>
						  </span>
					  <!-- checkbox -->
					  <input type="checkbox" id="basic_checkbox_1" class="filled-in">
					  <label for="basic_checkbox_1" class="mb-0 h-15 ml-15"></label>
					  <!-- todo text -->
					  <span class="text-line">Nulla vitae purus</span>
					  <!-- Emphasis label -->
					  <small class="badge bg-danger"><i class="fa fa-clock-o"></i> 2 mins</small>
					  <!-- General tools such as edit or delete-->
					  <div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					  </div>
					</li>
					<li>
						  <span class="handle">
							<i class="fa fa-ellipsis-v"></i>
							<i class="fa fa-ellipsis-v"></i>
						  </span>
					  <!-- checkbox -->
					  <input type="checkbox" id="basic_checkbox_2" class="filled-in">
					  <label for="basic_checkbox_2" class="mb-0 h-15 ml-15"></label>
					  <span class="text-line">Phasellus interdum</span>
					  <small class="badge bg-info"><i class="fa fa-clock-o"></i> 4 hours</small>
					  <div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					  </div>
					</li>
					<li>
						  <span class="handle">
							<i class="fa fa-ellipsis-v"></i>
							<i class="fa fa-ellipsis-v"></i>
						  </span>
					  <!-- checkbox -->
					  <input type="checkbox" id="basic_checkbox_3" class="filled-in">
					  <label for="basic_checkbox_3" class="mb-0 h-15 ml-15"></label>
					  <span class="text-line">Quisque sodales</span>
					  <small class="badge bg-warning"><i class="fa fa-clock-o"></i> 1 day</small>
					  <div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					  </div>
					</li>
					<li>
						  <span class="handle">
							<i class="fa fa-ellipsis-v"></i>
							<i class="fa fa-ellipsis-v"></i>
						  </span>
					  <!-- checkbox -->
					  <input type="checkbox" id="basic_checkbox_4" class="filled-in">
					  <label for="basic_checkbox_4" class="mb-0 h-15 ml-15"></label>
					  <span class="text-line">Proin nec mi porta</span>
					  <small class="badge bg-success"><i class="fa fa-clock-o"></i> 3 days</small>
					  <div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					  </div>
					</li>
					<li>
						  <span class="handle">
							<i class="fa fa-ellipsis-v"></i>
							<i class="fa fa-ellipsis-v"></i>
						  </span>
					  <!-- checkbox -->
					  <input type="checkbox" id="basic_checkbox_5" class="filled-in">
					  <label for="basic_checkbox_5" class="mb-0 h-15 ml-15"></label>
					  <span class="text-line">Maecenas scelerisque</span>
					  <small class="badge bg-primary"><i class="fa fa-clock-o"></i> 1 week</small>
					  <div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					  </div>
					</li>
					<li>
						  <span class="handle">
							<i class="fa fa-ellipsis-v"></i>
							<i class="fa fa-ellipsis-v"></i>
						  </span>
					  <!-- checkbox -->
					  <input type="checkbox" id="basic_checkbox_6" class="filled-in">
					  <label for="basic_checkbox_6" class="mb-0 h-15 ml-15"></label>
					  <span class="text-line">Vivamus nec orci</span>
					  <small class="badge bg-info"><i class="fa fa-clock-o"></i> 1 month</small>
					  <div class="tools">
						<i class="fa fa-edit"></i>
						<i class="fa fa-trash-o"></i>
					  </div>
					</li>
				  </ul>
				</div>
				<!-- /.box-body -->
			  <!-- /.box -->  
		</div>

        </div>	
		 
		<div class="col-lg-6 col-12">
			<div class="box">
				<div class="box-header with-border">
				  <h4 class="box-title">Task manager</h4>

				  <ul class="box-controls pull-right">
					  <li><a class="box-btn-close" href="#"></a></li>
					  <li><a class="box-btn-slide" href="#"></a></li>	
					  <li><a class="box-btn-fullscreen" href="#"></a></li>
					</ul>
				</div>
				<!-- /.box-header -->
				<div class="box-body">
					<div class="table-responsive">
					  <table class="table">
						<tbody>
							<tr>
							  <th>#</th>
							  <th>Task Description</th>
							  <th>Priority</th>
							  <th>Task Date</th>
							  <th>Status</th>
							  <th>User</th>
							</tr>
							<tr>
							  <td>1.</td>
							  <td>Nullam rhoncus</td>
							  <td>
								<span class="badge bg-danger">Highest</span>
							  </td>
							  <td>2019-Apr-04</td>
							  <td>
								<span class="badge bg-info">Open</span>
							  </td>
							  <td>Joshua</td>
							</tr>
							<tr>
							  <td>2.</td>
							  <td>Consectetur Adipiscing</td>
							  <td>
								<span class="badge bg-warning">HIGH</span>
							  </td>
							  <td>2019-Apr-15</td>
							  <td>
								<span class="badge bg-success">Resolved</span>
							  </td>
							  <td>Andrew</td>
							</tr>
							<tr>
							  <td>3.</td>
							  <td>Nullam rhoncus</td>
							  <td>
								<span class="badge bg-danger">Highest</span>
							  </td>
							  <td>2019-Apr-18</td>
							  <td>
								<span class="badge bg-success">Open</span>
							  </td>
							  <td>Joshua</td>
							</tr>
							<tr>
							  <td>4.</td>
							  <td>Vitae Lorem</td>
							  <td>
								<span class="badge bg-danger">Highest</span>
							  </td>
							  <td>2019-Apr-22</td>
							  <td>
								<span class="badge bg-primary">On Hold</span>
							  </td>
							  <td>James</td>
							</tr>
							<tr>
							  <td>5.</td>
							  <td>Nullam rhoncus</td>
							  <td>
								<span class="badge bg-primary">Low</span>
							  </td>
							  <td>2019-Apr-04</td>
							  <td>
								<span class="badge bg-success">Open</span>
							  </td>
							  <td>Joshua</td>
							</tr>
							<tr>
							  <td>6.</td>
							  <td>Nullam rhoncus</td>
							  <td>
								<span class="badge bg-danger">Highest</span>
							  </td>
							  <td>2019-Apr-04</td>
							  <td>
								<span class="badge bg-success">Open</span>
							  </td>
							  <td>Joshua</td>
							</tr>
						  </tbody>
						</table>
					</div>
				</div>
				<!-- /.box-body -->
			  </div>  
		</div> 
		
		<div class="col-12 col-lg-3"> 
          <div class="box">
            <div class="box-header with-border">
              <h4 class="box-title">Website Traffic</h4>
				<ul class="box-controls pull-right">
                  <li><a class="box-btn-close" href="#"></a></li>
                  <li><a class="box-btn-slide" href="#"></a></li>	
                  <li><a class="box-btn-fullscreen" href="#"></a></li>
                </ul>
            </div>
            <div class="box-body">
                <div class="chart">
				  <div id="e_chart_1" class="" style="height:188px;"></div>
				</div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
		  <div class="box bg-success">			
			<div class="box-body">
				<div class="row">
     				<div class="col-6">
					  <div class="text-center p-15">
						<div class="vertical-align-middle">
						  <div class="font-size-40">
							27°
							<span class="font-size-24">C</span>
						  </div>
						  <div class="mt-3">Miami, USA</div>
						</div>
					  </div>
					</div>
       				<!-- /.col -->
       				<div class="col-6">
					  <div class="text-center p-15" style="border-left: 1px solid rgba(255, 255, 255, 0.3);">
						<div class="vertical-align-middle">
						  <div class="font-size-40">
							<i class="wi-cloudy"></i>
						  </div>
						  <div class="mt-3">20.5.2018</div>
						</div>
					  </div>
					</div>
       				<!-- /.col -->
       			</div>
       			<!-- /.row -->
			</div>
			<!-- /.box-body -->
		  </div>	
			
        </div>	
		  
		<div class="col-12 col-lg-3"> 
          <div class="box">
            <div class="box-header with-border">
              <h4 class="box-title">USA</h4>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            	<div id="usa" style="height: 353px"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>		  
      </div>      
      <!-- /.row -->	      
	</section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->