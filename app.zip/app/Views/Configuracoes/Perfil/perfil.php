<div class="page-content-wrapper">
    <div class="page-content">
        <!-- BEGIN PAGE HEAD -->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h3>Perfil</h3>
            </div>
            <!-- END PAGE TITLE -->
        </div>
        <?php helper('mensagem');?>
        <div class="row">		
            <div class="col-md-12">         
                <div class="portlet box blue-hoki">
                    <div class="portlet-title">
                        <div class="caption">Lista de perfis</div>
                        <div class="pull-right" style="padding: 9px 0 9px 0;">
                            <a href="/Configuracoes/Perfil/perfilCriar"><button type="button" class="btn bg-green btn-sm"><i   class="fa fa-plus"></i> Novo</button></a>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div class="table">
                            <table id="perfis" class="table nowrap table-striped" style="width:100%; white-space: nowrap;">
                                <thead>
                                    <tr>
                                        <th style="display: none;">ID</th>
                                        <th style="text-align: center; width: 100px;">Ações</th>
                                        <th>Nome</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        if($resultados != ""){
                                            foreach ($resultados->getResult() as $resultado) {
                                                echo '<tr>';
                                                    echo '	<td style="display:none">'.$resultado->ID_PERFIL.'</td>';
                                                    echo '	<td align="center">';	
                                                    echo '		<a href="/Configuracoes/Perfil/perfilEditar/'.base64_encode($resultado->ID_PERFIL).'" >';
                                                    echo '<button class="btn bg-green btn-list-icon" title="Editar informações"><i class="fa fa-edit "></i></button>';
                                                    echo '		</a>';
                                                    echo '		<a href="#">';
                                                    echo '<button class="btn bg-red btn-list-icon" title="Excluir informações" title="Excluir informações" id='.base64_encode($resultado->ID_PERFIL).'><i class="fa fa-trash "></i></button>';
                                                    echo '		</a>';
                                                    echo '	</td>';
                                                    echo '	<td>'.mb_strtoupper($resultado->DESCRICAO,'UTF-8').'</td>';
                                                echo '</tr>';
                                            }
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>   <!-- /.box-body -->
                </div>
            </div>
        </div>
    </div>
</div>     <!-- /.box -->
<script src="/template/assets/global/scripts/perfis.js"></script>