<?php
    $id_perfil  = "";
    $descricao  = "";

    /*if($this->input->get('idperfil')!==null){
        $id_perfil = base64_decode($this->input->get('idperfil'));
        $descricao = base64_decode($this->input->get('descricao'));
    }*/
?>
<style>
    ol{
        list-style: none;
    }
</style>
<div class="page-content-wrapper">
    <div class="page-content">
        <!-- BEGIN PAGE HEAD -->
        <div class="page-head">
            <!-- BEGIN PAGE TITLE -->
            <div class="page-title">
                <h3>Perfil</h3>
            </div>
            <!-- END PAGE TITLE -->            
        </div>
        <!-- END PAGE HEAD -->
        <?php helper('mensagem');?>
        <div class="row">		
            <div class="col-md-12">         
                <div class="portlet box blue-hoki">
                    <div class="portlet-title">
                        <div class="caption">perfis do sistema</div>
                    </div>
                    <div class="portlet-body">
                        <form novalidate action="/Configuracoes/Perfil/perfilInserir" method="POST" id="frmPermissoes"> 
                        <?= csrf_field() ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <h5>Descrição</h5>
                                        <div class="controls">
                                            <input type="hidden" name="perfil_id" id="perfil_id" value="<?php echo isset($perfil->ID_PERFIL) ? $perfil->ID_PERFIL : '';?>">
                                            <input type="text" name="perfil_descricao" id="perfil_descricao" class="form-control" required data-validation-required-message="Campo obrigatório" minlength="6" data-validation-minlength-message="Informe um nome válido (min 6 caracteres)" value="<?php echo isset($perfil->DESCRICAO) ? $perfil->DESCRICAO : '';?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <fieldset>
                                        <input type="checkbox" id="permissoes_chk_all">
                                        <label for="permissoes_chk_all">Marcar todas as opções</label>
                                    </fieldset>
                                    <div class="row">
                                        <div class="col-md-4">
                                        <!-- Default box -->
                                            <div class="box">
                                                <div class="box-header with-border">
                                                    <h4 class="box-title">Configurações</h4>
                                                </div>
                                                <div class="box-body">
                                                    <div class="myadmin-dd">
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#usuario" aria-expanded="false" aria-controls="usuario"><i class="fa fa-plus"></i> Usuários</div>
                                                                <ol class="dd-list controls collapse" id="usuario" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="usuarios_chk_cons" value="2" class="checkboxes" name="checkperm[]">
                                                                                <label for="usuarios_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="usuario_chk_ins" value="3" class="checkboxes" name="checkperm[]">
                                                                                <label for="usuario_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="usuario_chk_edt" value="4" class="checkboxes" name="checkperm[]">
                                                                                <label for="usuario_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#permissoes" aria-expanded="false" aria-controls="permissoes"><i class="fa fa-plus"></i> Permissões</div>
                                                                <ol class="dd-list controls collapse" id="permissoes" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="permissoes_chk_cons" value="5" class="checkboxes" name="checkperm[]">
                                                                                <label for="permissoes_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="permissoes_chk_mod" value="6" class="checkboxes" name="checkperm[]">
                                                                                <label for="permissoes_chk_mod">Modificar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#perfil" aria-expanded="false" aria-controls="perfil"><i class="fa fa-plus"></i> Perfil</div>
                                                                <ol class="dd-list controls collapse" id="perfil" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="perfil_chk_cons" value="7" class="checkboxes" name="checkperm[]">
                                                                                <label for="perfil_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#log" aria-expanded="false" aria-controls="log"><i class="fa fa-plus"></i> Logs</div>
                                                                <ol class="dd-list controls collapse" id="log" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="log_chk_cons" value="8" class="checkboxes" name="checkperm[]">
                                                                                <label for="log_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="col-md-4">
                                        <!-- Default box -->
                                            <<!-- div class="box">
                                                <div class="box-header with-border">
                                                    <h4 class="box-title">Planos</h4>
                                                </div>
                                                <div class="box-body">
                                                    <div class="myadmin-dd">
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#planos" aria-expanded="false" aria-controls="planos"><i class="fa fa-plus"></i> Planos</div>
                                                                <ol class="dd-list controls collapse" id="planos" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="planos_chk_cons" value="60" class="checkboxes" name="checkperm[]">
                                                                                <label for="planos_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="planos_chk_ins" value="63" class="checkboxes" name="checkperm[]">
                                                                                <label for="planos_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="planos_chk_edt" value="64" class="checkboxes" name="checkperm[]">
                                                                                <label for="planos_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="planos_chk_exc" value="65" class="checkboxes" name="checkperm[]">
                                                                                <label for="planos_chk_exc">Excluir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div>  -->
                                        </div>
                                    <!--     <div class="col-md-4">
                                        
                                            <div class="box">
                                                <div class="box-header with-border">
                                                    <h4 class="box-title">Associados</h4>
                                                </div>
                                                <div class="box-body">
                                                    <div class="myadmin-dd">
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#fisico" aria-expanded="false" aria-controls="fisico"><i class="fa fa-plus"></i> Físico</div>
                                                                <ol class="dd-list controls collapse" id="fisico" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="fisico_chk_cons" value="66" class="checkboxes" name="checkperm[]">
                                                                                <label for="fisico_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="fisico_chk_ins" value="67" class="checkboxes" name="checkperm[]">
                                                                                <label for="fisico_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="fisico_chk_edt" value="68" class="checkboxes" name="checkperm[]">
                                                                                <label for="fisico_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="fisico_chk_exc" value="69" class="checkboxes" name="checkperm[]">
                                                                                <label for="fisico_chk_exc">Excluir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#juridico" aria-expanded="false" aria-controls="juridico"><i class="fa fa-plus"></i> Jurídico</div>
                                                                <ol class="dd-list controls collapse" id="juridico" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="juridico_chk_cons" value="70" class="checkboxes" name="checkperm[]">
                                                                                <label for="juridico_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="juridico_chk_ins" value="71" class="checkboxes" name="checkperm[]">
                                                                                <label for="juridico_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="juridico_chk_edt" value="72" class="checkboxes" name="checkperm[]">
                                                                                <label for="juridico_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="juridico_chk_exc" value="73" class="checkboxes" name="checkperm[]">
                                                                                <label for="juridico_chk_exc">Excluir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div> -->
                                    </div>
                                    <div class="row">
                                        <!-- <div class="col-md-4">
                                
                                            <div class="box">
                                                <div class="box-header with-border">
                                                    <h4 class="box-title">Relatórios</h4>
                                                </div>
                                                <div class="box-body">
                                                    <div class="myadmin-dd">
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#rel_ped" aria-expanded="false" aria-controls="rel_ped"><i class="fa fa-plus"></i> Pedidos</div>
                                                                <ol class="dd-list controls collapse" id="rel_ped" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="rel_ped_chk_cons" value="70" class="checkboxes" name="checkperm[]">
                                                                                <label for="rel_ped_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#cpf" aria-expanded="false" aria-controls="cpf"><i class="fa fa-plus"></i> CPF</div>
                                                                <ol class="dd-list controls collapse" id="cpf" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="cpf_chk_cons" value="80" class="checkboxes" name="checkperm[]">
                                                                                <label for="cpf_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#produtividade" aria-expanded="false" aria-controls="produtividade"><i class="fa fa-plus"></i> Produtividade</div>
                                                                <ol class="dd-list controls collapse" id="produtividade" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="produtividade_chk_cons" value="81" class="checkboxes" name="checkperm[]">
                                                                                <label for="produtividade_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div> -->
                                        <!-- <div class="col-md-4"> -->
                                        <!-- Default box -->
                                           <!--  <div class="box">
                                                <div class="box-header with-border">
                                                    <h4 class="box-title">Cadastros</h4>
                                                </div>
                                                <div class="box-body">
                                                    <div class="myadmin-dd">
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#prof" aria-expanded="false" aria-controls="prof"><i class="fa fa-plus"></i> Profissao</div>
                                                                <ol class="dd-list controls collapse" id="prof" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="prof_chk_cons" value="86" class="checkboxes" name="checkperm[]">
                                                                                <label for="prof_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="prof_chk_ins" value="87" class="checkboxes" name="checkperm[]">
                                                                                <label for="prof_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="prof_chk_edt" value="88" class="checkboxes" name="checkperm[]">
                                                                                <label for="prof_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="prof_chk_exc" value="89" class="checkboxes" name="checkperm[]">
                                                                                <label for="prof_chk_exc">Excluir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div> -->
                                        <!-- <div class="col-md-4">
                                        
                                            <div class="box">
                                                <div class="box-header with-border">
                                                    <h4 class="box-title">Portal do conhecimento</h4>
                                                </div>
                                                <div class="box-body">
                                                    <div class="myadmin-dd">
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#categoria" aria-expanded="false" aria-controls="categoria"><i class="fa fa-plus"></i> Categoria</div>
                                                                <ol class="dd-list controls collapse" id="categoria" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="categoria_chk_cons" value="90" class="checkboxes" name="checkperm[]">
                                                                                <label for="categoria_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="categoria_chk_ins" value="91" class="checkboxes" name="checkperm[]">
                                                                                <label for="categoria_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="categoria_chk_edt" value="92" class="checkboxes" name="checkperm[]">
                                                                                <label for="categoria_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="categoria_chk_exc" value="93" class="checkboxes" name="checkperm[]">
                                                                                <label for="categoria_chk_exc">Excluir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                        <ol class="dd-list">
                                                            <li class="dd-item">
                                                                <div class="dd-handle collapsed" data-toggle="collapse" data-target="#posts" aria-expanded="false" aria-controls="posts"><i class="fa fa-plus"></i> Posts</div>
                                                                <ol class="dd-list controls collapse" id="posts" aria-expanded="false" class="collapse">
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="posts_chk_cons" value="94" class="checkboxes" name="checkperm[]">
                                                                                <label for="posts_chk_cons">Consultar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="posts_chk_ins" value="95" class="checkboxes" name="checkperm[]">
                                                                                <label for="posts_chk_ins">Inserir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="posts_chk_edt" value="96" class="checkboxes" name="checkperm[]">
                                                                                <label for="posts_chk_edt">Editar</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                    <li class="dd-item">
                                                                        <div class="dd-handle collapsed">
                                                                            <fieldset>
                                                                                <input type="checkbox" id="posts_chk_exc" value="97" class="checkboxes" name="checkperm[]">
                                                                                <label for="posts_chk_exc">Excluir</label>
                                                                            </fieldset>
                                                                        </div>
                                                                    </li>
                                                                </ol>
                                                            </li>
                                                        </ol>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div> -->
                                    </div> 
                                    <div class="text-xs-right bt-1 pt-10">
                                        <div class="pull-right">
                                        <input type="hidden" name="gravar" value="ok">
                                            <button type="button" id="gravar_permissoes" class="btn btn-sm blue"><span class="fa fa-save"> Salvar</span></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>     <!-- /.box -->
<script src="/template/assets/global/scripts/perfis.min.js"></script>