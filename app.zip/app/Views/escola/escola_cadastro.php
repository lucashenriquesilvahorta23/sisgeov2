 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Escolas
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Escolas</a></li>
        <li class="breadcrumb-item active"><?php echo isset($escolas->ID_ESCOLA) ? 'Edição' : 'Cadastro';?> de escola</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
        <div class="row">	
            <div class="col-lg-12 col-12">
                    <div class="box box-solid bg-login">
                    <div class="box-header with-border">
                        <h4 class="box-title"><?php echo isset($escolas->ID_ESCOLA) ? 'Edição' : 'Cadastro';?> de escola</h4>			
                        <ul class="box-controls pull-right">
                            <li><a class="box-btn-close" href="#"></a></li>
                            <li><a class="box-btn-slide" href="#"></a></li>	
                            <li><a class="box-btn-fullscreen" href="#"></a></li>
                        </ul>
                    </div>
                    <!-- /.box-header -->
                    <form class="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Escola</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Nome da escola" name="nome" required id="nome">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>CNPJ</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control cnpj" placeholder="xx.xxx.xxx/xxxx-xx" name="cnpj" required id="cnpj">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Funcionamento</label> <span class="text-danger">*</span>
                                        <select name="funcionamento" required id="funcionamento" class="form-control">
                                            <option value="MA">Manhã</option>
                                            <option value="TA">Tarde</option>
                                            <option value="NT">Manhã e Tarde</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>INEP</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Nº INEP" name="inep" required id="inep">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>CME</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="CME - Resolução nº" name="cme" required id="cme">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control tel" placeholder="(xx) xxxx-xxxx" name="tel" required id="tel">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>E-mail</label> <span class="text-danger">*</span>
                                        <input type="email" class="form-control" placeholder="contato@sigeo.com.br" name="email" required id="email">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>CEP</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control cep" placeholder="0000-000" name="cep" required id="cep">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Cidade</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Nome da cidade" name="cidade" required id="cidade">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Logradouro</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Rua X, S/N" name="endereco" required id="endereco">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Bairro</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="Nome do bairro" name="bairro" required id="bairro">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Gestor</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control" placeholder="João da Silva" name="gestor" required id="gestor">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone gestor</label> <span class="text-danger">*</span>
                                        <input type="text" class="form-control tel" placeholder="(xx) xxxx-xxxx" name="tel_g" required id="tel_g">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-right">
                            <button type="button" class="btn btn-warning btn-outline mr-1">
                                <i class="fa fa-times"></i> Cancelar
                            </button>
                            <button type="submit" class="btn btn-primary btn-outline">
                                <i class="fa fa-save"></i> Salvar
                            </button>
                        </div>  
                    </form>
                    </div>
                    <!-- /.box -->			
            </div>  
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script src="/template/js/escola.js"></script>