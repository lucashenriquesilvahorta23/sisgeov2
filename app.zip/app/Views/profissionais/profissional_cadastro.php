 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      Profissional
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Profissional</a></li>
        <li class="breadcrumb-item active"><?php echo isset($profissional->ID_PROFISSIONAL) ? 'Edição' : 'Cadastro';?> de profissional</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
     
        <div class="row">	
            <div class="col-lg-12 col-12">
                    <div class="box box-solid bg-login">
                    <div class="box-header with-border">
                        <h4 class="box-title"><?php echo isset($profissional->ID_PROFISSIONAL) ? 'Edição' : 'Cadastro';?> de profissional</h4>			
                        <ul class="box-controls pull-right">
                            <li><a class="box-btn-close" href="#"></a></li>
                            <li><a class="box-btn-slide" href="#"></a></li>	
                            <li><a class="box-btn-fullscreen" href="#"></a></li>
                        </ul>
                    </div>
                    <!-- /.box-header -->
                    <form novalidate method="POST" action="/Profissional/Store" id="frmCliente_cadastro" class="validate" enctype='multipart/form-data'>
                        <div class="box-body">
                            <!-- Linha 1 -->
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Código</label>
                                        <input disabled="disabled" type="text" class="form-control" value="<?php echo isset($profissional->ID_PROFISSIONAL) ? $profissional->ID_PROFISSIONAL : '';?>" >
                                        <input type="hidden" class="form-control" value="<?php echo isset($profissional->ID_PROFISSIONAL) ? $profissional->ID_PROFISSIONAL : '';?>" name="profissional_id">
                                    </div>
                                </div>
                                <div class="col-md-3">                      
                                    <div class="form-group">
                                        <label>Foto profissional</label>
                                        <div class="controls">
                                            <input type="file" name="profissional_imagem" id="profissional_imagem" class="form-control">
                                        </div>
                                        <p >Foto do profissional<br> <?php if(isset($profissional->NOME_ALEATORIO)){echo '<a style="color: #000;" target="_blank" href="'.LINK_UPLOAD.$profissional->NOME_ALEATORIO.'">Clique para ver a imagem</a>';}?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Nome do profissional *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->NOME_PROFISSIONAL) ? $profissional->NOME_PROFISSIONAL : '';?>" name="profissional_nome" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Data de nascimento *</label>
                                        <input type="date" class="form-control" value="<?php echo isset($profissional->DATA_NASCIMENTO) ? $profissional->DATA_NASCIMENTO : '';?>" name="profissional_data_nascimento" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Idade *</label>
                                        <input type="number" class="form-control" value="<?php echo isset($profissional->IDADE) ? $profissional->IDADE : '';?>" name="profissional_idade" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Sexo *</label>
                                        <select class="form-control" name="profissional_sexo" required>
                                            <option <?php if(isset($profissional->SEXO) && $profissional->SEXO == 'M'){echo 'selected';}?> value="M">Masculino</option>
                                            <option <?php if(isset($profissional->SEXO) && $profissional->SEXO == 'F'){echo 'selected';}?> value="F">Feminino</option>
                                            <option <?php if(isset($profissional->SEXO) && $profissional->SEXO == 'O'){echo 'selected';}?> value="O">Outro</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 5 - Filiação 1 -->
                            <h5>Filiação</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Filiação 1 *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($profissional->FILIACAO_1) ? $profissional->FILIACAO_1 : '';?>" name="profissional_filiacao_1" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Filiação 2 *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->FILIACAO_2) ? $profissional->FILIACAO_2 : '';?>" name="profissional_filiacao_2" required>
                                    </div>
                                </div>
                            </div>


                            <!-- Linha 2 -->
                            <div class="row">
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Naturalidade *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->NATURALIDADE) ? $profissional->NATURALIDADE : '';?>" name="profissional_naturalidade" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Estado *</label>
                                        <select class="form-control" name="profissional_estado_naturalidade" required>
                                            <option value="AC" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'AC'){echo 'selected';}?> >Acre (AC)</option>
                                            <option value="AL" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'AL'){echo 'selected';}?> >Alagoas (AL)</option>
                                            <option value="AP" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'AP'){echo 'selected';}?> >Amapá (AP)</option>
                                            <option value="AM" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'AM'){echo 'selected';}?> >Amazonas (AM)</option>
                                            <option value="BA" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'BA'){echo 'selected';}?> >Bahia (BA)</option>
                                            <option value="CE" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'CE'){echo 'selected';}?> >Ceará (CE)</option>
                                            <option value="DF" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'DF'){echo 'selected';}?> >Distrito Federal (DF)</option>
                                            <option value="ES" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'ES'){echo 'selected';}?> >Espírito Santo (ES)</option>
                                            <option value="GO" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'GO'){echo 'selected';}?> >Goiás (GO)</option>
                                            <option value="MA" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'MA'){echo 'selected';}?> >Maranhão (MA)</option>
                                            <option value="MT" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'MT'){echo 'selected';}?> >Mato Grosso (MT)</option>
                                            <option value="MS" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'MS'){echo 'selected';}?> >Mato Grosso do Sul (MS)</option>
                                            <option value="MG" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'MG'){echo 'selected';}?> >Minas Gerais (MG)</option>
                                            <option value="PA" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'PA'){echo 'selected';}?> >Pará (PA)</option>
                                            <option value="PB" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'PB'){echo 'selected';}?> >Paraíba (PB)</option>
                                            <option value="PR" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'PR'){echo 'selected';}?> >Paraná (PR)</option>
                                            <option value="PE" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'PE'){echo 'selected';}?> >Pernambuco (PE)</option>
                                            <option value="PI" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'PI'){echo 'selected';}?> >Piauí (PI)</option>
                                            <option value="RJ" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'RJ'){echo 'selected';}?> >Rio de Janeiro (RJ)</option>
                                            <option value="RN" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'RN'){echo 'selected';}?> >Rio Grande do Norte (RN)</option>
                                            <option value="RS" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'RS'){echo 'selected';}?> >Rio Grande do Sul (RS)</option>
                                            <option value="RO" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'RO'){echo 'selected';}?> >Rondônia (RO)</option>
                                            <option value="RR" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'RR'){echo 'selected';}?> >Roraima (RR)</option>
                                            <option value="SC" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'SC'){echo 'selected';}?> >Santa Catarina (SC)</option>
                                            <option value="SP" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'SP'){echo 'selected';}?> >São Paulo (SP)</option>
                                            <option value="SE" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'SE'){echo 'selected';}?> >Sergipe (SE)</option>
                                            <option value="TO" <?php if(isset($profissional->ESTADO_NATURALIDADE) && $profissional->ESTADO_NATURALIDADE == 'TO'){echo 'selected';}?> >Tocantins (TO)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Cor ou Raça *</label>
                                        <select class="form-control" name="profissional_cor_raca" required>
                                            <option <?php if(isset($profissional->COR_RACA) && $profissional->COR_RACA == 'BR'){echo 'selected';}?> value="BR">Branco</option>
                                            <option <?php if(isset($profissional->COR_RACA) && $profissional->COR_RACA == 'AM'){echo 'selected';}?> value="AM">Amarelo</option>
                                            <option <?php if(isset($profissional->COR_RACA) && $profissional->COR_RACA == 'IN'){echo 'selected';}?> value="IN">Indigena</option>
                                            <option <?php if(isset($profissional->COR_RACA) && $profissional->COR_RACA == 'NG'){echo 'selected';}?> value="NG">Negro</option>
                                            <option <?php if(isset($profissional->COR_RACA) && $profissional->COR_RACA == 'PD'){echo 'selected';}?> value="PD">Pardo</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Estado Civil *</label>
                                        <select name="profissional_estado_civil" required id="profissional_estado_civil" class="form-control">
                                            <option <?php if(isset($profissional->ESTADO_CIVIL) && $profissional->ESTADO_CIVIL == 'SOL'){echo 'selected';}?> value="SOL">Solteiro(a)</option>
                                            <option <?php if(isset($profissional->ESTADO_CIVIL) && $profissional->ESTADO_CIVIL == 'CAS'){echo 'selected';}?> value="CAS">Casado(a)</option>
                                            <option <?php if(isset($profissional->ESTADO_CIVIL) && $profissional->ESTADO_CIVIL == 'DIV'){echo 'selected';}?> value="DIV">Divorciado(a)</option>
                                            <option <?php if(isset($profissional->ESTADO_CIVIL) && $profissional->ESTADO_CIVIL == 'VIU'){echo 'selected';}?> value="VIU">Viúvo(a)</option>
                                            <option <?php if(isset($profissional->ESTADO_CIVIL) && $profissional->ESTADO_CIVIL == 'UNI'){echo 'selected';}?> value="UNI">União Estável</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 3 -->
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>CPF *</label>
                                        <input type="text" class="form-control cpf"  value="<?php echo isset($profissional->CPF) ? $profissional->CPF : '';?>" name="profissional_cpf" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Data de emissão *</label>
                                        <input type="date" class="form-control"  value="<?php echo isset($profissional->DATA_EMISSAO) ? $profissional->DATA_EMISSAO : '';?>" name="profissional_data_emissao" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Orgão expeditor *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($profissional->ORGAO_EXPEDITOR) ? $profissional->ORGAO_EXPEDITOR : '';?>" name="profissional_orgao_expeditor" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Titulo de eleitor *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($profissional->TITULO_ELEITOR) ? $profissional->TITULO_ELEITOR : '';?>" name="profissional_titulo_eleitor" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Zone *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($profissional->ZONA) ? $profissional->ZONA : '';?>" name="profissional_zona" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Seção *</label>
                                        <input type="text" class="form-control"  value="<?php echo isset($profissional->SECAO) ? $profissional->SECAO : '';?>" name="profissional_secao" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Linha 8 - Endereço -->
                            <h5>Endereço</h5>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Endereço *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->ENDERECO) ? $profissional->ENDERECO : '';?>" name="profissional_endereco" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Número *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->NUMERO) ? $profissional->NUMERO : '';?>" name="profissional_numero" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bairro *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->BAIRRO) ? $profissional->BAIRRO : '';?>" name="profissional_bairro" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Cidade *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->CIDADE) ? $profissional->CIDADE : '';?>" name="profissional_cidade" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Estado *</label>
                                        <select class="form-control" name="profissional_estado" required>
                                            <option value="AC" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'AC'){echo 'selected';}?> >Acre (AC)</option>
                                            <option value="AL" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'AL'){echo 'selected';}?> >Alagoas (AL)</option>
                                            <option value="AP" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'AP'){echo 'selected';}?> >Amapá (AP)</option>
                                            <option value="AM" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'AM'){echo 'selected';}?> >Amazonas (AM)</option>
                                            <option value="BA" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'BA'){echo 'selected';}?> >Bahia (BA)</option>
                                            <option value="CE" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'CE'){echo 'selected';}?> >Ceará (CE)</option>
                                            <option value="DF" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'DF'){echo 'selected';}?> >Distrito Federal (DF)</option>
                                            <option value="ES" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'ES'){echo 'selected';}?> >Espírito Santo (ES)</option>
                                            <option value="GO" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'GO'){echo 'selected';}?> >Goiás (GO)</option>
                                            <option value="MA" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'MA'){echo 'selected';}?> >Maranhão (MA)</option>
                                            <option value="MT" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'MT'){echo 'selected';}?> >Mato Grosso (MT)</option>
                                            <option value="MS" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'MS'){echo 'selected';}?> >Mato Grosso do Sul (MS)</option>
                                            <option value="MG" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'MG'){echo 'selected';}?> >Minas Gerais (MG)</option>
                                            <option value="PA" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'PA'){echo 'selected';}?> >Pará (PA)</option>
                                            <option value="PB" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'PB'){echo 'selected';}?> >Paraíba (PB)</option>
                                            <option value="PR" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'PR'){echo 'selected';}?> >Paraná (PR)</option>
                                            <option value="PE" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'PE'){echo 'selected';}?> >Pernambuco (PE)</option>
                                            <option value="PI" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'PI'){echo 'selected';}?> >Piauí (PI)</option>
                                            <option value="RJ" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'RJ'){echo 'selected';}?> >Rio de Janeiro (RJ)</option>
                                            <option value="RN" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'RN'){echo 'selected';}?> >Rio Grande do Norte (RN)</option>
                                            <option value="RS" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'RS'){echo 'selected';}?> >Rio Grande do Sul (RS)</option>
                                            <option value="RO" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'RO'){echo 'selected';}?> >Rondônia (RO)</option>
                                            <option value="RR" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'RR'){echo 'selected';}?> >Roraima (RR)</option>
                                            <option value="SC" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'SC'){echo 'selected';}?> >Santa Catarina (SC)</option>
                                            <option value="SP" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'SP'){echo 'selected';}?> >São Paulo (SP)</option>
                                            <option value="SE" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'SE'){echo 'selected';}?> >Sergipe (SE)</option>
                                            <option value="TO" <?php if(isset($profissional->ESTADO) && $profissional->ESTADO == 'TO'){echo 'selected';}?> >Tocantins (TO)</option>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone 1 *</label>
                                        <input type="text" class="form-control telefone" value="<?php echo isset($profissional->TELEFONE_1) ? $profissional->TELEFONE_1 : '';?>" name="profissional_telefone_1" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Telefone 2 *</label>
                                        <input type="text" class="form-control telefone" value="<?php echo isset($profissional->TELEFONE_2) ? $profissional->TELEFONE_2 : '';?>" name="profissional_telefone_2" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->EMAIL) ? $profissional->EMAIL : '';?>" name="profissional_email" required>
                                    </div>
                                </div>
                            </div>
                            <br>

                            <!-- Linha 3 -->
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Nível de escolaridade concluído</label>
                                        <div class="d-flex">
                                            <div class="form-check me-2">
                                                <input class="form-check-input" type="radio" name="profissional_escolaridade" <?php if(isset($profissional->ESCOLARIDADE) && $profissional->ESCOLARIDADE == "F"){echo "checked";}?> id="fundamental" value="F">
                                                <label class="form-check-label" for="fundamental">Fundamental</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="profissional_escolaridade" <?php if(isset($profissional->ESCOLARIDADE) && $profissional->ESCOLARIDADE == "M"){echo "checked";}?> id="media" value="M">
                                                <label class="form-check-label" for="media">Médio</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="profissional_escolaridade" <?php if(isset($profissional->ESCOLARIDADE) && $profissional->ESCOLARIDADE == "S"){echo "checked";}?> id="superior" value="S">
                                                <label class="form-check-label" for="superior">Superior</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="profissional_escolaridade" <?php if(isset($profissional->ESCOLARIDADE) && $profissional->ESCOLARIDADE == "I"){echo "checked";}?> id="fundamental_nao_concluido" value="I">
                                                <label class="form-check-label" for="fundamental_nao_concluido">Fundamental não concluido</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nome do curso superior *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->CURSO_SUPERIOR) ? $profissional->CURSO_SUPERIOR : '';?>" name="profissional_curso_superior" required>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Nível / Grau Acadêmico</label>
                                        <div class="d-flex">
                                            <div class="form-check me-2">
                                                <input class="form-check-input" type="radio" name="profissional_nivel_grau_academico" <?php if(isset($profissional->NIVEL_GRAU_ACADEMICO) && $profissional->NIVEL_GRAU_ACADEMICO == "B"){echo "checked";}?> id="bacharelado" value="B">
                                                <label class="form-check-label" for="bacharelado">Bacharelado</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="profissional_nivel_grau_academico" <?php if(isset($profissional->NIVEL_GRAU_ACADEMICO) && $profissional->NIVEL_GRAU_ACADEMICO == "L"){echo "checked";}?> id="licenciatura" value="L">
                                                <label class="form-check-label" for="licenciatura">Licenciatura</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h5>Especializações concluidas</h5>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Especialização 1 *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->ESPECIALIZACAO_1) ? $profissional->ESPECIALIZACAO_1 : '';?>" name="profissional_especializacao_1" required>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Especialização 2 *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->ESPECIALIZACAO_2) ? $profissional->ESPECIALIZACAO_2 : '';?>" name="profissional_especializacao_2" required>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Especialização 3 *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->ESPECIALIZACAO_3) ? $profissional->ESPECIALIZACAO_3 : '';?>" name="profissional_especializacao_3" required>
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Cargo *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->CARGO) ? $profissional->CARGO : '';?>" name="profissional_cargo" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Carga-horário *</label>
                                        <input type="text" class="form-control" value="<?php echo isset($profissional->CARGA_HORARIA) ? $profissional->CARGA_HORARIA : '';?>" name="profissional_carga_horaria" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Horário entrada *</label>
                                        <input type="text" class="form-control horario" value="<?php echo isset($profissional->HORARIO_ENTRADA) ? $profissional->HORARIO_ENTRADA : '';?>" name="profissional_horario_entrada" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Horário saída *</label>
                                        <input type="text" class="form-control horario" value="<?php echo isset($profissional->HORARIO_SAIDA) ? $profissional->HORARIO_SAIDA : '';?>" name="profissional_horario_saida" required>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Intervalo</label>
                                        <div class="d-flex">
                                            <div class="form-check me-2">
                                                <input class="form-check-input" type="radio" name="profissional_intervalo" <?php if(isset($profissional->INTERVALO) && $profissional->INTERVALO == "S"){echo "checked";}?> id="sim" value="S">
                                                <label class="form-check-label" for="sim">Sim</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="profissional_intervalo" <?php if(isset($profissional->INTERVALO) && $profissional->INTERVALO == "N"){echo "checked";}?> id="nao" value="N">
                                                <label class="form-check-label" for="nao">Não</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Quantas horas? *</label>
                                        <input type="number" class="form-control" value="<?php echo isset($profissional->INTERVALO_HORA) ? $profissional->INTERVALO_HORA : '';?>" name="profissional_intervalo_hora" required>
                                    </div>
                                </div>

                            </div>

                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tipo de vinculo *</label>
                                        <select name="profissional_tipo_vinculo" id="profissional_tipo_vinculo" class="form-control" required>
                                            <option value="">Selecione o tipo de vínculo</option>
                                            <option <?php if(isset($profissional->TIPO_VINCULO) && $profissional->TIPO_VINCULO == 'CT'){echo 'selected';}?> value="CT">CTPS</option>
                                            <option <?php if(isset($profissional->TIPO_VINCULO) && $profissional->TIPO_VINCULO == 'AT'){echo 'selected';}?> value="AT">Autônomo</option>
                                            <option <?php if(isset($profissional->TIPO_VINCULO) && $profissional->TIPO_VINCULO == 'PJ'){echo 'selected';}?> value="PJ">PJ</option>
                                            <option <?php if(isset($profissional->TIPO_VINCULO) && $profissional->TIPO_VINCULO == 'ET'){echo 'selected';}?> value="ET">Estagiário</option>
                                            <option <?php if(isset($profissional->TIPO_VINCULO) && $profissional->TIPO_VINCULO == 'FR'){echo 'selected';}?> value="FR">Freelancer</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Data de admissão *</label>
                                        <input type="date" class="form-control" value="<?php echo isset($profissional->DATA_ADMISSAO) ? $profissional->DATA_ADMISSAO : '';?>" name="profissional_data_admissao" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Data de desligamento </label>
                                        <input type="date" class="form-control" value="<?php echo isset($profissional->DATA_DESLIGAMENTO) ? $profissional->DATA_DESLIGAMENTO : '';?>" name="profissional_data_desligamento">
                                    </div>
                                </div>
                                

                            </div>

                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-right">
                            <button type="submit" class="btn btn-warning btn-outline mr-1">
                                <i class="fa fa-times"></i> Cancelar
                            </button>
                            <button type="submit" class="btn btn-primary btn-outline">
                                <i class="fa fa-save"></i> Salvar
                            </button>
                        </div>  
                    </form>
                    </div>
                    <!-- /.box -->			
            </div>  
        </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <script src="/template/js/escola.js"></script>